#!/usr/bin/env python3
"""
final_clean.py  —  Remove bookmarks, tracked changes, rsid attrs from docx,
                   then apply academic styles and save the final submission file.
"""
import zipfile, shutil, os
from lxml import etree
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'

REMOVE_TAGS = {
    qn('w:ins'), qn('w:del'),
    qn('w:rPrChange'), qn('w:pPrChange'), qn('w:sectPrChange'),
    qn('w:tblPrChange'), qn('w:trPrChange'), qn('w:tcPrChange'),
    qn('w:moveFrom'), qn('w:moveTo'),
    qn('w:moveFromRangeStart'), qn('w:moveFromRangeEnd'),
    qn('w:moveToRangeStart'),  qn('w:moveToRangeEnd'),
}

RSID_ATTRS = {qn('w:rsidR'), qn('w:rsidDel'), qn('w:rsidRPr'),
              qn('w:rsidTr'), qn('w:rsidSect')}

BOOKMARK_TAGS = {qn('w:bookmarkStart'), qn('w:bookmarkEnd')}


def process_document_xml(data: bytes) -> bytes:
    tree = etree.fromstring(data)

    # Accept tracked insertions, remove deletions, remove change-records
    for _ in range(4):
        for elem in list(tree.iter()):
            tag = elem.tag
            parent = elem.getparent()
            if parent is None:
                continue
            if tag == qn('w:ins'):
                idx = list(parent).index(elem)
                for child in list(elem):
                    parent.insert(idx, child)
                    idx += 1
                parent.remove(elem)
            elif tag in REMOVE_TAGS:
                parent.remove(elem)

    # Remove all bookmarks (these render as [ ] brackets in Word)
    for elem in list(tree.iter()):
        if elem.tag in BOOKMARK_TAGS:
            parent = elem.getparent()
            if parent is not None:
                parent.remove(elem)

    # Remove rsid revision attributes (cause margin bars)
    for elem in tree.iter():
        for attr in list(elem.attrib):
            if attr in RSID_ATTRS or 'rsid' in attr.lower():
                del elem.attrib[attr]

    return etree.tostring(tree, xml_declaration=True,
                          encoding='UTF-8', standalone=True)


def process_settings_xml(data: bytes) -> bytes:
    tree = etree.fromstring(data)
    for tag in (qn('w:trackChanges'), qn('w:revisionView')):
        for el in tree.findall('.//' + tag):
            el.getparent().remove(el)
    return etree.tostring(tree, xml_declaration=True,
                          encoding='UTF-8', standalone=True)


EMPTY_COMMENTS = (
    b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    b'<w:comments xmlns:w="http://schemas.openxmlformats.org/'
    b'wordprocessingml/2006/main"/>'
)


def clean_docx(src: str, dst: str):
    tmp = src + '.bak'
    shutil.copy(src, tmp)
    with zipfile.ZipFile(tmp, 'r') as zin, \
         zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == 'word/document.xml':
                data = process_document_xml(data)
            elif item.filename == 'word/settings.xml':
                data = process_settings_xml(data)
            elif item.filename in ('word/comments.xml',
                                   'word/commentsExtended.xml',
                                   'word/commentsExtensible.xml'):
                data = EMPTY_COMMENTS
            zout.writestr(item, data)
    os.remove(tmp)
    print(f'  Cleaned → {dst}')


def add_page_numbers(doc):
    section = doc.sections[0]
    footer  = section.footer
    para    = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    para.clear()
    run = para.add_run()
    for kind, text in [('begin', None), (None, 'PAGE'), ('end', None)]:
        if kind:
            fc = OxmlElement('w:fldChar')
            fc.set(qn('w:fldCharType'), kind)
            run._r.append(fc)
        else:
            it = OxmlElement('w:instrText')
            it.set(qn('xml:space'), 'preserve')
            it.text = text
            run._r.append(it)


def apply_styles(path: str):
    doc = Document(path)

    for sec in doc.sections:
        sec.top_margin    = Cm(2.5)
        sec.bottom_margin = Cm(2.5)
        sec.left_margin   = Cm(3.0)
        sec.right_margin  = Cm(2.5)

    n = doc.styles['Normal']
    n.font.name = 'Times New Roman'
    n.font.size = Pt(12)
    n.paragraph_format.space_after  = Pt(6)
    n.paragraph_format.space_before = Pt(0)
    n.paragraph_format.line_spacing = Pt(18)

    for hname, hsize, hbold, hrgb in [
        ('Heading 1', Pt(16), True,  RGBColor(0x1a, 0x1a, 0x2e)),
        ('Heading 2', Pt(14), True,  RGBColor(0x16, 0x21, 0x3e)),
        ('Heading 3', Pt(12), True,  RGBColor(0x0f, 0x3d, 0x6b)),
        ('Heading 4', Pt(12), False, RGBColor(0x0f, 0x3d, 0x6b)),
    ]:
        if hname in doc.styles:
            s = doc.styles[hname]
            s.font.name      = 'Times New Roman'
            s.font.size      = hsize
            s.font.bold      = hbold
            s.font.color.rgb = hrgb
            s.paragraph_format.space_before = Pt(12)
            s.paragraph_format.space_after  = Pt(6)

    avail = [s.name for s in doc.styles]
    tbl_sty = next((n for n in
                    ('Table Grid', 'TableGrid', 'Light Grid', 'Light Shading')
                    if n in avail), None)
    for table in doc.tables:
        if tbl_sty:
            try:
                table.style = tbl_sty
            except Exception:
                pass
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    para.paragraph_format.space_before = Pt(3)
                    para.paragraph_format.space_after  = Pt(3)
                    for run in para.runs:
                        run.font.name = 'Times New Roman'
                        run.font.size = Pt(10)

    add_page_numbers(doc)
    doc.save(path)
    print(f'  Styled  → {path}')


if __name__ == '__main__':
    RAW  = 'output/COM713_Full_Report_raw.docx'
    FINAL = 'COM713_Full_Report.docx'

    print('Step 1: Removing bookmarks, tracked changes, revision marks...')
    clean_docx(RAW, FINAL)

    print('Step 2: Applying academic styles...')
    apply_styles(FINAL)

    # Quick verification
    import zipfile as zf
    with zf.ZipFile(FINAL) as z:
        imgs   = [n for n in z.namelist() if n.startswith('word/media/')]
        xmlraw = z.read('word/document.xml')
    from lxml import etree as ET
    tree = ET.fromstring(xmlraw)
    bm   = tree.findall(f'.//{{{W}}}bookmarkStart')
    ins  = tree.findall(f'.//{{{W}}}ins')
    rsid = [e for e in tree.iter() if any('rsid' in a for a in e.attrib)]
    print(f'\n✅ Verification:')
    print(f'   Bookmarks remaining : {len(bm)}')
    print(f'   w:ins remaining     : {len(ins)}')
    print(f'   rsid attrs remaining: {len(rsid)}')
    print(f'   Images embedded     : {len(imgs)}')
    print(f'   File size           : {os.path.getsize(FINAL)//1024} KB')
    print(f'\n📄 Output: {FINAL}')

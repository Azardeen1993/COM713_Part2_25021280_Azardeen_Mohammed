"""
Data Loader for Medical Text Classification
===========================================
Module: COM713 - Advanced Data Structures and Algorithms
Author: [Student Name]
Date: 2026

Handles reading the dataset from CSV, shuffling, and splitting into
training and testing sets. Avoids using pandas for the core logic to
demonstrate fundamental algorithm implementation (like Fisher-Yates shuffle),
though it uses the standard csv module for parsing.
"""

import csv
import random
from collections import Counter


class DataLoader:
    """
    Loads, processes, and splits the medical text dataset.
    """

    def __init__(self, file_path):
        """
        Initialise DataLoader with file path.

        Args:
            file_path (str): Path to the dataset CSV file.
        """
        self.file_path = file_path
        self.data = []    # List of (text, label) tuples
        self.texts = []   # Parallel list of texts
        self.labels = []  # Parallel list of labels

    def load_csv(self, text_col='text', label_col='label'):
        """
        Read the CSV file into memory.

        Args:
            text_col (str): Column name containing the text.
            label_col (str): Column name containing the category label.

        Time Complexity: O(N) where N is number of rows.
        Space Complexity: O(N) memory to store texts and labels.
        """
        self.data = []
        self.texts = []
        self.labels = []

        try:
            with open(self.file_path, mode='r', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                
                # Check if expected columns exist
                if not reader.fieldnames:
                    raise ValueError("CSV file is empty or missing headers.")
                
                # Handle possible alternative column names (Kaggle datasets vary)
                actual_text_col = text_col if text_col in reader.fieldnames else reader.fieldnames[0]
                actual_label_col = label_col if label_col in reader.fieldnames else reader.fieldnames[1]

                for row in reader:
                    text = row.get(actual_text_col, "").strip()
                    label = row.get(actual_label_col, "").strip()
                    
                    if text and label:
                        self.data.append((text, label))
                        self.texts.append(text)
                        self.labels.append(label)
                        
            print(f"Successfully loaded {len(self.data)} records from {self.file_path}")
            return True
            
        except FileNotFoundError:
            print(f"Error: Dataset file not found at {self.file_path}")
            return False
        except Exception as e:
            print(f"Error loading dataset: {e}")
            return False

    def _fisher_yates_shuffle(self, arr):
        """
        In-place Fisher-Yates shuffle algorithm.

        Time Complexity: O(N)
        Space Complexity: O(1)
        """
        n = len(arr)
        for i in range(n - 1, 0, -1):
            j = random.randint(0, i)
            arr[i], arr[j] = arr[j], arr[i]

    def split_data(self, test_ratio=0.2, random_seed=42):
        """
        Shuffle and split data into training and testing sets.

        Args:
            test_ratio (float): Proportion of data to use for testing.
            random_seed (int): Seed for reproducibility.

        Time Complexity: O(N)
        Space Complexity: O(N) for creating split lists.

        Returns:
            tuple: (X_train, y_train, X_test, y_test)
        """
        if not self.data:
            raise ValueError("No data loaded. Call load_csv() first.")

        # Set seed for reproducibility
        random.seed(random_seed)

        # Create indices and shuffle them using our implementation
        indices = list(range(len(self.data)))
        self._fisher_yates_shuffle(indices)

        # Calculate split index
        split_idx = int(len(self.data) * (1 - test_ratio))

        # Split indices
        train_indices = indices[:split_idx]
        test_indices = indices[split_idx:]

        # Create output arrays
        X_train = [self.texts[i] for i in train_indices]
        y_train = [self.labels[i] for i in train_indices]
        X_test = [self.texts[i] for i in test_indices]
        y_test = [self.labels[i] for i in test_indices]

        return X_train, y_train, X_test, y_test

    def get_class_distribution(self):
        """
        Calculate the distribution of classes in the dataset.

        Time Complexity: O(N)
        
        Returns:
            dict: Mapping of class label to count.
        """
        return dict(Counter(self.labels))

# pipeline package
# Contains the data loader and the master classification pipeline
from .data_loader import DataLoader
from .pipeline import ClassificationPipeline

"""
Master Pipeline for Medical Text Classification
===============================================
Module: COM713 - Advanced Data Structures and Algorithms
Author: [Student Name]
Date: 2026

This module orchestrates the entire classification process, linking the
data structures (Trie, Heap, BST) with the NLP components (Tokenizer,
TF-IDF) and the Ensemble Classifier.

It implements the Queue data structure (using collections.deque) to
process incoming documents in a FIFO manner during inference.
"""

import sys
import os
import time
from collections import deque

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from nlp.preprocessor import TextPreprocessor
from nlp.tokenizer import MedicalTokenizer
from nlp.tfidf_engine import TFIDFVectorizer
from classification.classifier import EnsembleClassifier
from classification.evaluator import ModelEvaluator
from classification.explainer import ClassificationExplainer
from pipeline.data_loader import DataLoader


class ClassificationPipeline:
    """
    Master orchestrator for the Medical Text Classification system.
    """

    def __init__(self, data_path, max_vocab_size=5000, min_freq=3):
        """
        Initialise the full pipeline.

        Args:
            data_path (str): Path to the dataset CSV.
            max_vocab_size (int): Max terms in the Trie.
            min_freq (int): Minimum document frequency for a term.
        """
        self.data_path = data_path
        
        # Instantiate components
        self.data_loader = DataLoader(data_path)
        self.preprocessor = TextPreprocessor()
        self.tokenizer = MedicalTokenizer(self.preprocessor, min_freq, max_vocab_size)
        
        # Vectorizer, classifier, evaluator and explainer will be instantiated later
        self.vectorizer = None
        
        # Classifier, evaluator and explainer will be instantiated after vocab is built
        self.classifier = None
        self.evaluator = None
        self.explainer = None
        
        # Queue for batch processing (FIFO)
        self.inference_queue = deque()
        
        self.is_trained = False

    def train(self, test_ratio=0.2):
        """
        Execute the full training pipeline.
        """
        start_time = time.time()
        print("="*50)
        print("STARTING TRAINING PIPELINE")
        print("="*50)

        # 1. Load Data
        print("\n1. Loading Data...")
        if not self.data_loader.load_csv():
            return False
            
        # 2. Split Data
        print("\n2. Splitting Data (Fisher-Yates Shuffle)...")
        X_train, y_train, X_test, y_test = self.data_loader.split_data(test_ratio)
        print(f"Train size: {len(X_train)} | Test size: {len(X_test)}")
        
        # 3. Build Vocabulary (Trie)
        print("\n3. Building Medical Vocabulary (Trie)...")
        t_start = time.time()
        self.tokenizer.fit(X_train, y_train)
        print(f"Vocabulary built: {self.tokenizer.get_vocab_size()} unique terms.")
        print(f"Time taken: {time.time() - t_start:.2f}s")
        
        # 4. Feature Engineering (TF-IDF)
        print("\n4. Feature Engineering (TF-IDF Sparse Vectors)...")
        t_start = time.time()
        self.vectorizer = TFIDFVectorizer(self.tokenizer)
        X_train_tfidf = self.vectorizer.fit_transform(X_train)
        print(f"TF-IDF matrices computed.")
        print(f"Time taken: {time.time() - t_start:.2f}s")
        
        # 5. Train Classifier
        print("\n5. Training Ensemble Classifier...")
        t_start = time.time()
        self.classifier = EnsembleClassifier(vocab_size=self.tokenizer.get_vocab_size())
        self.classifier.train(X_train_tfidf, y_train)
        print(f"Time taken: {time.time() - t_start:.2f}s")
        
        # 6. Evaluate Model
        print("\n6. Evaluating on Test Set...")
        X_test_tfidf = [self.vectorizer.transform(doc) for doc in X_test]
        y_pred = self.classifier.predict(X_test_tfidf)
        
        self.evaluator = ModelEvaluator(self.classifier.classes)
        report = self.evaluator.classification_report(y_test, y_pred)
        print("\n" + report)
        
        # 7. Setup Explainer
        self.explainer = ClassificationExplainer(self.tokenizer, self.vectorizer, self.classifier)
        
        self.is_trained = True
        print("="*50)
        print(f"PIPELINE COMPLETE (Total Time: {time.time() - start_time:.2f}s)")
        print("="*50)
        
        return True

    def enqueue_document(self, text):
        """
        Add a document to the inference queue.
        Demonstrates use of the Queue data structure.
        """
        self.inference_queue.append(text)
        print(f"Document added to queue. Queue size: {len(self.inference_queue)}")

    def process_queue(self):
        """
        Process all documents in the inference queue (FIFO).
        """
        if not self.is_trained:
            print("Pipeline must be trained first.")
            return []
            
        results = []
        while self.inference_queue:
            # FIFO: pop from left
            doc = self.inference_queue.popleft()
            
            # Extract features
            tfidf_vec = self.vectorizer.transform(doc)
            
            # Predict
            pred = self.classifier.predict([tfidf_vec])[0]
            results.append((doc, pred))
            
        return results

    def explain(self, text, top_k=5):
        """
        Explain a single prediction.
        """
        if not self.is_trained:
            return "Pipeline must be trained first."
            
        return self.explainer.generate_explanation_report(text, top_k)

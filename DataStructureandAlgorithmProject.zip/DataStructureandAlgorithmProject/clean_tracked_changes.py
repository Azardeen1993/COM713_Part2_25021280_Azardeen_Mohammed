#!/usr/bin/env python3
"""
clean_tracked_changes.py
Remove all Word tracked-change markup (revision bars, insertions, deletions,
format-change marks, comments) from COM713_Full_Report.docx.
Then re-apply academic styles and save the clean output.
"""
import zipfile, shutil, os, re
from lxml import etree

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

# ── Tags that constitute tracked-change markup ────────────────────────────────
TRACKED_CHANGE_TAGS = {
    qn('w:ins'),          # inserted run
    qn('w:del'),          # deleted run
    qn('w:rPrChange'),    # run-property change
    qn('w:pPrChange'),    # paragraph-property change
    qn('w:sectPrChange'), # section-property change
    qn('w:tblPrChange'),  # table-property change
    qn('w:trPrChange'),   # row-property change
    qn('w:tcPrChange'),   # cell-property change
    qn('w:moveFrom'),     # moved-from
    qn('w:moveTo'),       # moved-to
    qn('w:moveFromRangeStart'),
    qn('w:moveFromRangeEnd'),
    qn('w:moveToRangeStart'),
    qn('w:moveToRangeEnd'),
}

# rsid / revision attributes to scrub from every element
REVISION_ATTRS = {
    qn('w:rsidR'),   qn('w:rsidDel'), qn('w:rsidRPr'),
    qn('w:rsidTr'),  qn('w:rsidSect'),
}


def accept_tracked_changes(root: etree._Element):
    """
    Walk the XML tree and:
      - For w:ins  → keep the child runs (accept insertion)
      - For w:del  → discard the element entirely (accept deletion)
      - For *Change variants → remove the element (keep current value)
    """
    for elem in root.iter():
        tag = elem.tag
        parent = elem.getparent()
        if parent is None:
            continue

        if tag == qn('w:ins'):
            # Accept: lift children into parent
            idx = list(parent).index(elem)
            for child in list(elem):
                parent.insert(idx, child)
                idx += 1
            parent.remove(elem)

        elif tag == qn('w:del'):
            # Accept: discard deleted content
            parent.remove(elem)

        elif tag in TRACKED_CHANGE_TAGS - {qn('w:ins'), qn('w:del')}:
            # Property-change record — just remove it; current value stays
            parent.remove(elem)


def scrub_revision_attrs(root: etree._Element):
    """Remove rsid* attributes that cause revision bars."""
    for elem in root.iter():
        for attr in REVISION_ATTRS:
            if attr in elem.attrib:
                del elem.attrib[attr]


def disable_track_changes(root: etree._Element):
    """Set w:trackChanges to off in document settings."""
    # Find or create w:settings root
    settings_ns = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    for tc in root.findall('.//' + qn('w:trackChanges')):
        tc.getparent().remove(tc)


def remove_comments(doc_path_in, doc_path_out):
    """
    Open the docx zip, clean document.xml and comments.xml, repack.
    """
    tmp = doc_path_in + '.tmp.zip'
    shutil.copy(doc_path_in, tmp)

    with zipfile.ZipFile(tmp, 'r') as zin, \
         zipfile.ZipFile(doc_path_out, 'w', zipfile.ZIP_DEFLATED) as zout:

        for item in zin.infolist():
            data = zin.read(item.filename)

            if item.filename == 'word/document.xml':
                tree = etree.fromstring(data)
                # Run three passes (nested tracked changes need multiple passes)
                for _ in range(3):
                    accept_tracked_changes(tree)
                scrub_revision_attrs(tree)
                data = etree.tostring(tree, xml_declaration=True,
                                      encoding='UTF-8', standalone=True)

            elif item.filename in ('word/comments.xml',
                                   'word/commentsExtended.xml',
                                   'word/commentsExtensible.xml'):
                # Replace with empty comments container
                data = (b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                        b'<w:comments xmlns:w="http://schemas.openxmlformats.org/'
                        b'wordprocessingml/2006/main"/>')

            elif item.filename == 'word/settings.xml':
                tree = etree.fromstring(data)
                disable_track_changes(tree)
                # Remove revision view settings
                for tag in (qn('w:revisionView'), qn('w:trackChanges')):
                    for el in tree.findall('.//' + tag):
                        el.getparent().remove(el)
                data = etree.tostring(tree, xml_declaration=True,
                                      encoding='UTF-8', standalone=True)

            zout.writestr(item, data)

    os.remove(tmp)
    print(f"Tracked changes removed → {doc_path_out}")


def add_page_numbers(doc):
    section = doc.sections[0]
    footer  = section.footer
    para    = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    para.clear()
    run = para.add_run()
    for tag, text in [('begin', None), (None, 'PAGE'), ('end', None)]:
        if tag:
            fc = OxmlElement('w:fldChar')
            fc.set(qn('w:fldCharType'), tag)
            run._r.append(fc)
        else:
            it = OxmlElement('w:instrText')
            it.set(qn('xml:space'), 'preserve')
            it.text = text
            run._r.append(it)


def apply_styles(doc_path):
    doc = Document(doc_path)

    for section in doc.sections:
        section.top_margin    = Cm(2.5)
        section.bottom_margin = Cm(2.5)
        section.left_margin   = Cm(3.0)
        section.right_margin  = Cm(2.5)

    sn = doc.styles['Normal']
    sn.font.name = 'Times New Roman'
    sn.font.size = Pt(12)
    sn.paragraph_format.space_after  = Pt(6)
    sn.paragraph_format.space_before = Pt(0)
    sn.paragraph_format.line_spacing = Pt(18)

    for name, size, bold, rgb in [
        ('Heading 1', Pt(16), True,  RGBColor(0x1a, 0x1a, 0x2e)),
        ('Heading 2', Pt(14), True,  RGBColor(0x16, 0x21, 0x3e)),
        ('Heading 3', Pt(12), True,  RGBColor(0x0f, 0x3d, 0x6b)),
        ('Heading 4', Pt(12), False, RGBColor(0x0f, 0x3d, 0x6b)),
    ]:
        if name in doc.styles:
            s = doc.styles[name]
            s.font.name      = 'Times New Roman'
            s.font.size      = size
            s.font.bold      = bold
            s.font.color.rgb = rgb
            s.paragraph_format.space_before = Pt(12)
            s.paragraph_format.space_after  = Pt(6)

    # Tables
    available = [s.name for s in doc.styles]
    tbl_style = next((n for n in ('Table Grid', 'TableGrid',
                                  'Light Grid', 'Light Shading')
                      if n in available), None)
    for table in doc.tables:
        if tbl_style:
            try:
                table.style = tbl_style
            except Exception:
                pass
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    para.paragraph_format.space_before = Pt(3)
                    para.paragraph_format.space_after  = Pt(3)
                    for run in para.runs:
                        run.font.name = 'Times New Roman'
                        run.font.size = Pt(10)

    add_page_numbers(doc)
    doc.save(doc_path)
    print(f"Styles applied → {doc_path}")


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    RAW   = 'output/COM713_Full_Report_raw.docx'
    CLEAN = 'COM713_Full_Report.docx'

    print("Step 1: Removing tracked changes and revision marks...")
    remove_comments(RAW, CLEAN)

    print("Step 2: Applying academic styles...")
    apply_styles(CLEAN)

    print("\n✅  Done — clean document saved as:", CLEAN)

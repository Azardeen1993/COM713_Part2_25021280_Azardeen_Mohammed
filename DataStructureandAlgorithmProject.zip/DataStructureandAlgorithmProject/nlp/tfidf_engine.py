"""
Custom TF-IDF Vectorizer for Medical Text Classification
======================================================
Module: COM713 - Advanced Data Structures and Algorithms
Author: [Student Name]
Date: 2026

This module implements a custom Term Frequency-Inverse Document Frequency (TF-IDF)
vectorization engine. Rather than relying on Scikit-Learn's TfidfVectorizer,
this is implemented from scratch to demonstrate algorithmic understanding
and data structure utilisation (Hash Maps for sparse vector representation).

Key Features:
    - O(n × d) fit algorithm where n=docs, d=vocab
    - O(d) transform algorithm
    - Sparse dictionary representation for memory efficiency
    - L2 normalization for cosine similarity compatibility

References:
    - Salton, G. and McGill, M.J. (1983) Introduction to Modern Information Retrieval.
"""

import math
from collections import defaultdict

class TFIDFVectorizer:
    """
    Custom TF-IDF engine using Hash Maps for sparse representation.

    Instead of generating dense n × V matrices (where n is documents and V
    is vocabulary size), which would require massive memory for a 14k doc corpus,
    this class represents vectors as sparse dictionaries mapping index -> score.

    Attributes:
        tokenizer (MedicalTokenizer): Pre-fitted tokenizer.
        idf_scores (dict): Mapping of token_index -> IDF score.
        vocab_size (int): Total size of the vocabulary.
        num_documents (int): Total number of documents trained on.
    """

    def __init__(self, tokenizer):
        """
        Initialise the TF-IDF Vectorizer.

        Args:
            tokenizer (MedicalTokenizer): A fitted MedicalTokenizer containing
                                          the vocabulary and word indices.

        Time Complexity: O(1)
        """
        if not tokenizer.is_fitted:
            raise ValueError("Tokenizer must be fitted before passing to TFIDFVectorizer")

        self.tokenizer = tokenizer
        self.idf_scores = {}
        self.vocab_size = tokenizer.get_vocab_size()
        self.num_documents = 0
        self.is_fitted = False

    def fit(self, documents):
        """
        Calculate and store IDF (Inverse Document Frequency) scores for all terms.

        IDF(t) = log( (1 + N) / (1 + df(t)) ) + 1
        Where N is total documents and df(t) is document frequency of term t.
        Smooth IDF formula used to prevent zero division (similar to scikit-learn).

        Algorithm:
            1. Iterate over all documents
            2. Tokenize each document into unique term indices
            3. Count document frequency (df) for each term index
            4. Compute and store IDF score for each term index

        Args:
            documents (list[str]): List of raw document strings.

        Time Complexity: O(D × L) where D is number of docs, L is avg length.
        Space Complexity: O(V) where V is vocabulary size.

        Returns:
            TFIDFVectorizer: self
        """
        self.num_documents = len(documents)

        # Hash map to track document frequency: index -> count
        doc_freq = defaultdict(int)

        # Step 1-3: Calculate Document Frequencies
        for doc in documents:
            # Tokenize to indices and get unique indices for this document
            indices = set(self.tokenizer.tokenize_to_indices(doc))
            for idx in indices:
                doc_freq[idx] += 1

        # Step 4: Calculate IDF scores
        for word, idx in self.tokenizer.vocab.items():
            df = doc_freq.get(idx, 0)
            # Smooth IDF calculation
            idf = math.log((1 + self.num_documents) / (1 + df)) + 1
            self.idf_scores[idx] = idf

        self.is_fitted = True
        return self

    def transform(self, document):
        """
        Transform a single document into a TF-IDF feature vector.

        The vector is represented sparsely as a dictionary {index: score}.

        TF(t, d) = count of t in d / total terms in d

        Args:
            document (str): Raw document string.

        Time Complexity: O(L) where L is document length.
        Space Complexity: O(U) where U is number of unique valid terms in document.

        Returns:
            dict: Sparse feature vector {index: score}.
        """
        if not self.is_fitted:
            raise RuntimeError("Vectorizer must be fitted before transform")

        # Get indices for this document
        indices = self.tokenizer.tokenize_to_indices(document)
        total_terms = len(indices)

        if total_terms == 0:
            return {}

        # Calculate Term Frequency (TF)
        term_counts = defaultdict(int)
        for idx in indices:
            term_counts[idx] += 1

        # Calculate TF-IDF and apply L2 normalization
        vector = {}
        sum_sq = 0.0

        for idx, count in term_counts.items():
            tf = count / total_terms
            idf = self.idf_scores.get(idx, 1.0) # default to 1.0 if unseen but somehow tokenized
            tfidf_score = tf * idf
            vector[idx] = tfidf_score
            sum_sq += tfidf_score * tfidf_score

        # L2 Normalization (Euclidean norm)
        # Ensures all vectors have length 1, making cosine similarity = dot product
        if sum_sq > 0:
            norm = math.sqrt(sum_sq)
            for idx in vector:
                vector[idx] /= norm

        return vector

    def fit_transform(self, documents):
        """
        Fit to documents and then transform them.

        Args:
            documents (list[str]): List of documents.

        Time Complexity: O(D × L)
        Space Complexity: O(D × U) where U is avg unique terms per doc.

        Returns:
            list[dict]: List of sparse feature vectors.
        """
        self.fit(documents)
        return [self.transform(doc) for doc in documents]

    def get_feature_names(self):
        """
        Get the ordered list of feature names (vocabulary words).

        Returns:
            list[str]: Vocabulary words ordered by index.
        """
        # Create inverse mapping
        idx_to_word = {idx: word for word, idx in self.tokenizer.vocab.items()}
        # Return sorted by index
        return [idx_to_word[i] for i in range(self.vocab_size)]

    def __repr__(self):
        return f"TFIDFVectorizer(vocab_size={self.vocab_size}, fitted={self.is_fitted})"

"""
Text Preprocessor for Medical Text Classification
==================================================
Module: COM713 - Advanced Data Structures and Algorithms
Author: [Student Name]
Date: 2026

This module implements text preprocessing specifically tailored for
medical abstracts and clinical text. Preprocessing is a critical step
in the NLP pipeline that transforms raw text into a clean, normalised
format suitable for feature extraction.

Preprocessing Steps:
    1. Lowercasing
    2. Punctuation and special character removal
    3. Number handling (replace with <NUM> token or remove)
    4. Stop word removal (using a comprehensive medical-aware stop word list)
    5. Abbreviation expansion (common medical abbreviations)
    6. Basic lemmatisation (suffix stripping for common patterns)

Design Decision:
    We implement custom preprocessing rather than relying on external NLP
    libraries (like NLTK or spaCy) to demonstrate algorithmic understanding
    and maintain full control over the pipeline. This aligns with the
    module's focus on data structures and algorithms.
"""

import re
import string


class TextPreprocessor:
    """
    A text preprocessing engine for medical documents.

    This class provides a pipeline of text cleaning and normalisation
    operations designed for medical text. Each operation is implemented
    as a separate method to enable flexible composition and testing.

    Attributes:
        stop_words (set): Set of stop words to remove from text.
                         Using a set provides O(1) membership testing.
        medical_abbreviations (dict): Mapping of abbreviations to expansions.
                                     Using a dict provides O(1) lookup.
        remove_numbers (bool): Whether to remove numerical tokens.

    Example Usage:
        >>> preprocessor = TextPreprocessor()
        >>> preprocessor.preprocess("The patient's CT scan showed NO abnormalities.")
        'patient ct scan showed abnormalities'
    """

    # Comprehensive English stop words list (avoiding external dependencies)
    DEFAULT_STOP_WORDS = {
        'a', 'an', 'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
        'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
        'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
        'could', 'should', 'may', 'might', 'shall', 'can', 'need', 'dare',
        'ought', 'used', 'it', 'its', 'this', 'that', 'these', 'those',
        'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you',
        'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his',
        'himself', 'she', 'her', 'hers', 'herself', 'itself', 'they', 'them',
        'their', 'theirs', 'themselves', 'what', 'which', 'who', 'whom',
        'when', 'where', 'why', 'how', 'all', 'each', 'every', 'both',
        'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not',
        'only', 'own', 'same', 'so', 'than', 'too', 'very', 'just', 'don',
        'now', 'about', 'above', 'after', 'again', 'against', 'between',
        'into', 'through', 'during', 'before', 'below', 'under', 'over',
        'then', 'once', 'here', 'there', 'further', 'also', 'however',
        'although', 'though', 'yet', 'still', 'already', 'while', 'if',
        'because', 'until', 'unless', 'since', 'whether', 'either',
        'neither', 'up', 'out', 'off', 'down', 'any', 'much', 'many',
        'being', 'having', 'doing', 'going', 'using', 'well', 'back',
        'even', 'given', 'rather', 'quite', 'often', 'thus', 'hence',
        'therefore', 'moreover', 'furthermore', 'nevertheless', 'nonetheless',
        'whereas', 'whereby', 'wherein', 'upon', 'within', 'without',
        'among', 'across', 'around', 'along', 'beside', 'besides',
        'beyond', 'despite', 'except', 'like', 'near', 'past',
        'regarding', 'unlike', 'via', 'versus', 'et', 'al', 'etc',
    }

    # Common medical abbreviations and their expansions
    DEFAULT_MEDICAL_ABBREVIATIONS = {
        'ecg': 'electrocardiogram',
        'eeg': 'electroencephalogram',
        'mri': 'magnetic resonance imaging',
        'ct': 'computed tomography',
        'bp': 'blood pressure',
        'hr': 'heart rate',
        'bmi': 'body mass index',
        'cns': 'central nervous system',
        'gi': 'gastrointestinal',
        'cv': 'cardiovascular',
        'copd': 'chronic obstructive pulmonary disease',
        'dvt': 'deep vein thrombosis',
        'pe': 'pulmonary embolism',
        'cad': 'coronary artery disease',
        'chf': 'congestive heart failure',
        'mi': 'myocardial infarction',
        'htn': 'hypertension',
        'dm': 'diabetes mellitus',
        'ckd': 'chronic kidney disease',
        'uti': 'urinary tract infection',
        'ards': 'acute respiratory distress syndrome',
        'icu': 'intensive care unit',
        'nsaid': 'nonsteroidal anti inflammatory drug',
        'ace': 'angiotensin converting enzyme',
        'arb': 'angiotensin receptor blocker',
        'ssri': 'selective serotonin reuptake inhibitor',
        'cbc': 'complete blood count',
        'bmp': 'basic metabolic panel',
        'lfts': 'liver function tests',
        'wbc': 'white blood cell',
        'rbc': 'red blood cell',
        'hgb': 'hemoglobin',
        'plt': 'platelet',
    }

    def __init__(self, stop_words=None, medical_abbreviations=None,
                 remove_numbers=True, min_word_length=2):
        """
        Initialise the TextPreprocessor with configuration options.

        Args:
            stop_words (set, optional): Custom stop words.
                                       Defaults to DEFAULT_STOP_WORDS.
            medical_abbreviations (dict, optional): Custom abbreviation mappings.
                                                   Defaults to DEFAULT_MEDICAL_ABBREVIATIONS.
            remove_numbers (bool): Whether to remove pure numeric tokens.
            min_word_length (int): Minimum word length to keep after tokenisation.

        Time Complexity: O(S + A) where S is stop_words size, A is abbreviations size.
        """
        # Use set for O(1) membership testing of stop words
        self.stop_words = stop_words if stop_words is not None else self.DEFAULT_STOP_WORDS.copy()

        # Use dict for O(1) abbreviation lookup
        self.medical_abbreviations = (
            medical_abbreviations if medical_abbreviations is not None
            else self.DEFAULT_MEDICAL_ABBREVIATIONS.copy()
        )

        self.remove_numbers = remove_numbers
        self.min_word_length = min_word_length

        # Precompile regex patterns for efficiency
        # This pattern matches any character that is NOT alphanumeric or whitespace
        self._punctuation_pattern = re.compile(r'[^\w\s]')
        # This pattern matches sequences of whitespace
        self._whitespace_pattern = re.compile(r'\s+')
        # This pattern matches pure numeric tokens
        self._number_pattern = re.compile(r'^\d+\.?\d*$')

    def preprocess(self, text):
        """
        Apply the full preprocessing pipeline to a text string.

        Pipeline order:
            1. Lowercase conversion
            2. Abbreviation expansion
            3. Punctuation removal
            4. Whitespace normalisation
            5. Tokenisation
            6. Number removal (if configured)
            7. Stop word removal
            8. Minimum word length filtering
            9. Rejoin into clean string

        Args:
            text (str): The raw input text to preprocess.

        Time Complexity: O(n) where n is the length of the text.
        Space Complexity: O(n) for the processed text.

        Returns:
            str: The cleaned, normalised text.
        """
        if not text or not isinstance(text, str):
            return ""

        # Step 1: Convert to lowercase for case-insensitive processing
        text = self.clean_text(text)

        # Step 2: Expand medical abbreviations
        text = self.expand_abbreviations(text)

        # Step 3: Tokenise (split into individual words)
        tokens = text.split()

        # Step 4: Remove stop words (O(1) per lookup using set)
        tokens = self.remove_stopwords(tokens)

        # Step 5: Apply basic lemmatisation
        tokens = self.lemmatize(tokens)

        # Step 6: Filter by minimum word length
        tokens = [t for t in tokens if len(t) >= self.min_word_length]

        # Rejoin tokens into a clean string
        return ' '.join(tokens)

    def clean_text(self, text):
        """
        Clean raw text by lowercasing, removing punctuation, and
        normalising whitespace.

        Args:
            text (str): Raw input text.

        Time Complexity: O(n) where n is the text length.

        Returns:
            str: Cleaned text.
        """
        # Lowercase
        text = text.lower()

        # Remove punctuation (keep only alphanumeric and whitespace)
        text = self._punctuation_pattern.sub(' ', text)

        # Normalise whitespace (collapse multiple spaces into one)
        text = self._whitespace_pattern.sub(' ', text).strip()

        return text

    def remove_stopwords(self, tokens):
        """
        Remove stop words from a list of tokens.

        Uses a set for O(1) membership testing per token,
        resulting in O(n) total time for n tokens.

        Args:
            tokens (list[str]): List of word tokens.

        Time Complexity: O(n) where n is the number of tokens.
        Space Complexity: O(n) for the filtered list.

        Returns:
            list[str]: Tokens with stop words removed.
        """
        return [
            token for token in tokens
            if token not in self.stop_words
            and (not self.remove_numbers or not self._number_pattern.match(token))
        ]

    def expand_abbreviations(self, text):
        """
        Expand common medical abbreviations in the text.

        Replaces known abbreviations with their full forms to improve
        term matching consistency (e.g., "ECG" → "electrocardiogram").

        Args:
            text (str): Text with potential abbreviations.

        Time Complexity: O(n × a) where n is the number of words
                        and a is the average abbreviation length.

        Returns:
            str: Text with abbreviations expanded.
        """
        words = text.split()
        expanded = []

        for word in words:
            # Check if the word is a known abbreviation (O(1) dict lookup)
            if word in self.medical_abbreviations:
                expanded.append(self.medical_abbreviations[word])
            else:
                expanded.append(word)

        return ' '.join(expanded)

    def lemmatize(self, tokens):
        """
        Apply basic suffix-stripping lemmatisation to tokens.

        This is a simplified rule-based lemmatiser that handles common
        English suffixes. For production use, a full morphological
        analyser (e.g., NLTK WordNetLemmatizer) would be preferred,
        but this custom implementation demonstrates the algorithm
        and avoids external dependencies.

        Rules applied (in order):
            - 'ies' → 'y' (e.g., 'studies' → 'study')
            - 'ves' → 'f' (e.g., 'nerves' → 'nerve' — kept as is to avoid errors)
            - 'ses', 'xes', 'zes', 'ches', 'shes' → remove 'es'
            - 'ness' → remove (e.g., 'effectiveness' → 'effective')
            - 'ment' → remove (e.g., 'treatment' → 'treat')
            - 'ing' → remove (e.g., 'treating' → 'treat')
            - 'tion' → remove (e.g., 'classification' → 'classifica')
            - 's' → remove (e.g., 'patients' → 'patient')

        Args:
            tokens (list[str]): List of word tokens to lemmatise.

        Time Complexity: O(n × m) where n is the number of tokens
                        and m is the average token length.

        Returns:
            list[str]: Lemmatised tokens.
        """
        lemmatised = []

        for token in tokens:
            # Skip short words (less likely to have meaningful suffixes)
            if len(token) <= 4:
                lemmatised.append(token)
                continue

            # Apply suffix rules (order matters for correctness)
            if token.endswith('ies') and len(token) > 4:
                token = token[:-3] + 'y'
            elif token.endswith('ness') and len(token) > 5:
                token = token[:-4]
            elif token.endswith('ment') and len(token) > 5:
                token = token[:-4]
            elif token.endswith('ing') and len(token) > 5:
                token = token[:-3]
            elif token.endswith('tion') and len(token) > 5:
                token = token[:-4]
            elif token.endswith('ses') and len(token) > 4:
                token = token[:-2]
            elif token.endswith('es') and len(token) > 4:
                token = token[:-2]
            elif token.endswith('s') and not token.endswith('ss') and len(token) > 3:
                token = token[:-1]

            lemmatised.append(token)

        return lemmatised

    def get_stats(self):
        """
        Return configuration statistics for the preprocessor.

        Returns:
            dict: Configuration details including stop word count,
                 abbreviation count, and settings.
        """
        return {
            'num_stop_words': len(self.stop_words),
            'num_abbreviations': len(self.medical_abbreviations),
            'remove_numbers': self.remove_numbers,
            'min_word_length': self.min_word_length
        }

    def __repr__(self):
        """String representation of the TextPreprocessor."""
        return (
            f"TextPreprocessor(stop_words={len(self.stop_words)}, "
            f"abbreviations={len(self.medical_abbreviations)}, "
            f"min_word_len={self.min_word_length})"
        )

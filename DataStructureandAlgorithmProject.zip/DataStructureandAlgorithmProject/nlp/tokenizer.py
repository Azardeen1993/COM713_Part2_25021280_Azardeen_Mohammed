"""
Medical Tokenizer for Medical Text Classification
==================================================
Module: COM713 - Advanced Data Structures and Algorithms
Author: [Student Name]
Date: 2026

This module implements a tokenizer that integrates with the MedicalTrie
data structure to provide efficient vocabulary management and token
lookup during the text classification pipeline.

The tokenizer builds a vocabulary from the training corpus and uses
the Trie for O(m) term validation, where m is the word length.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_structures.trie import MedicalTrie
from nlp.preprocessor import TextPreprocessor


class MedicalTokenizer:
    """
    A tokenizer designed for medical text that integrates with MedicalTrie
    for efficient vocabulary management.

    The MedicalTokenizer:
        1. Preprocesses text using TextPreprocessor
        2. Splits text into tokens
        3. Validates tokens against the vocabulary stored in a Trie
        4. Tracks word frequencies and category associations

    This tokenizer is specifically designed to work with the Trie data
    structure, providing O(m) lookup for each token (where m is the
    token length), compared to O(n) for a list-based vocabulary check.

    Attributes:
        preprocessor (TextPreprocessor): Text cleaning engine.
        trie (MedicalTrie): Vocabulary stored in a Trie for fast lookup.
        vocab (dict): Word-to-index mapping for vectorisation.
        word_freq (dict): Global word frequency counter.
        is_fitted (bool): Whether the tokenizer has been fitted to a corpus.

    Example Usage:
        >>> tokenizer = MedicalTokenizer()
        >>> tokenizer.fit(["Patient has cardiac arrest", "Tumor found in liver"])
        >>> tokens = tokenizer.tokenize("cardiac tumor diagnosis")
        >>> print(tokens)
        ['cardiac', 'tumor', 'diagnosis']
    """

    def __init__(self, preprocessor=None, min_freq=1, max_vocab_size=None):
        """
        Initialise the MedicalTokenizer.

        Args:
            preprocessor (TextPreprocessor, optional): Custom preprocessor.
                                                      Defaults to a new instance.
            min_freq (int): Minimum word frequency to include in vocabulary.
                           Words appearing fewer times are excluded.
            max_vocab_size (int, optional): Maximum vocabulary size.
                                          If set, only the most frequent words are kept.

        Time Complexity: O(1)
        """
        # Text preprocessing engine
        self.preprocessor = preprocessor if preprocessor else TextPreprocessor()

        # Trie for efficient vocabulary storage and lookup
        self.trie = MedicalTrie()

        # Word-to-index mapping (for converting tokens to feature indices)
        self.vocab = {}

        # Global word frequency counter (used for filtering rare words)
        self.word_freq = {}

        # Configuration
        self.min_freq = min_freq
        self.max_vocab_size = max_vocab_size

        # State flag
        self.is_fitted = False

    def fit(self, documents, categories=None):
        """
        Build the vocabulary from a corpus of documents.

        Algorithm:
            1. Preprocess each document
            2. Count word frequencies across the corpus
            3. Filter by minimum frequency
            4. Optionally limit vocabulary size (keep most frequent)
            5. Insert all vocabulary words into the Trie
            6. Build word-to-index mapping

        Args:
            documents (list[str]): List of document strings.
            categories (list[str], optional): Corresponding category labels.
                                            Used for category-frequency tracking in the Trie.

        Time Complexity: O(D × L) where D is the number of documents
                        and L is the average document length.
        Space Complexity: O(V × M) where V is vocabulary size
                         and M is average word length (for Trie storage).

        Returns:
            MedicalTokenizer: self (for method chaining).
        """
        # Reset state
        self.word_freq = {}
        self.trie = MedicalTrie()
        self.vocab = {}

        # Step 1 & 2: Preprocess and count word frequencies
        all_tokens_by_doc = []
        for i, doc in enumerate(documents):
            processed = self.preprocessor.preprocess(doc)
            tokens = processed.split()
            all_tokens_by_doc.append(tokens)

            # Count frequencies using hash map (O(1) per update)
            for token in tokens:
                if token not in self.word_freq:
                    self.word_freq[token] = 0
                self.word_freq[token] += 1

        # Step 3: Filter by minimum frequency
        filtered_words = {
            word: freq for word, freq in self.word_freq.items()
            if freq >= self.min_freq
        }

        # Step 4: Optionally limit vocabulary size
        if self.max_vocab_size and len(filtered_words) > self.max_vocab_size:
            # Sort by frequency (descending) and keep top N
            sorted_words = sorted(
                filtered_words.items(),
                key=lambda x: x[1],
                reverse=True
            )
            filtered_words = dict(sorted_words[:self.max_vocab_size])

        # Step 5: Insert vocabulary words into the Trie with category tracking
        for i, tokens in enumerate(all_tokens_by_doc):
            category = categories[i] if categories and i < len(categories) else None
            for token in tokens:
                if token in filtered_words:
                    self.trie.insert(token, category)

        # Step 6: Build word-to-index mapping (sorted for deterministic output)
        sorted_vocab = sorted(filtered_words.keys())
        self.vocab = {word: idx for idx, word in enumerate(sorted_vocab)}

        self.is_fitted = True
        return self

    def tokenize(self, text):
        """
        Tokenize a text string using the fitted vocabulary.

        Preprocesses the text and returns tokens that exist in the vocabulary.
        Unknown tokens (not in the Trie) are excluded.

        Args:
            text (str): The text to tokenize.

        Time Complexity: O(L × m) where L is the number of tokens
                        and m is the average token length (for Trie search).

        Returns:
            list[str]: List of validated tokens.
        """
        if not self.is_fitted:
            raise RuntimeError("Tokenizer must be fitted before use. Call fit() first.")

        # Preprocess the text
        processed = self.preprocessor.preprocess(text)
        tokens = processed.split()

        # Filter: only keep tokens in our vocabulary (Trie search is O(m))
        valid_tokens = [token for token in tokens if self.trie.search(token)]

        return valid_tokens

    def tokenize_to_indices(self, text):
        """
        Tokenize text and convert to vocabulary indices.

        Useful for creating numerical feature vectors.

        Args:
            text (str): The text to tokenize.

        Time Complexity: O(L × m) for tokenisation + O(L) for index lookup.

        Returns:
            list[int]: List of vocabulary indices for each valid token.
        """
        tokens = self.tokenize(text)
        return [self.vocab[token] for token in tokens if token in self.vocab]

    def get_vocab_size(self):
        """
        Return the size of the vocabulary.

        Returns:
            int: Number of unique words in the vocabulary.
        """
        return len(self.vocab)

    def get_word_index(self, word):
        """
        Get the vocabulary index of a word.

        Args:
            word (str): The word to look up.

        Returns:
            int or None: The index, or None if the word is not in the vocabulary.
        """
        return self.vocab.get(word.lower(), None)

    def get_index_word(self, index):
        """
        Get the word at a given vocabulary index.

        Args:
            index (int): The vocabulary index.

        Returns:
            str or None: The word, or None if the index is invalid.
        """
        # Build reverse mapping (lazy, cached)
        if not hasattr(self, '_index_to_word') or len(self._index_to_word) != len(self.vocab):
            self._index_to_word = {idx: word for word, idx in self.vocab.items()}

        return self._index_to_word.get(index, None)

    def get_word_frequency(self, word):
        """
        Get the corpus frequency of a word.

        Args:
            word (str): The word to query.

        Returns:
            int: Frequency count, or 0 if not found.
        """
        return self.word_freq.get(word.lower(), 0)

    def __repr__(self):
        """String representation of the MedicalTokenizer."""
        return (
            f"MedicalTokenizer(vocab_size={len(self.vocab)}, "
            f"min_freq={self.min_freq}, "
            f"fitted={self.is_fitted})"
        )

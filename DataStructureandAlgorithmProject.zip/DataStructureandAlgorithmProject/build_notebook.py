import nbformat as nbf
import os
import glob

def read_file(filepath):
    with open(filepath, 'r') as f:
        return f.read()

def create_notebook():
    nb = nbf.v4.new_notebook()
    
    cells = []
    
    # Title
    cells.append(nbf.v4.new_markdown_cell("# COM713 – Advanced Data Structures and Algorithms\n## Medical Text Classification using Advanced Data Structures & NLP\n**Author:** [Student Name]\n**Date:** 2026\n\nThis notebook contains the complete implementation of the Medical Text Classification pipeline, including custom data structures (Trie, Min-Heap, BST) and a custom TF-IDF engine."))
    
    # Imports
    imports = """import math
import re
import csv
import random
import time
from collections import defaultdict, Counter, deque
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import matplotlib.pyplot as plt
import seaborn as sns"""
    
    cells.append(nbf.v4.new_markdown_cell("### 1. Imports & Setup"))
    cells.append(nbf.v4.new_code_cell(imports))
    
    # Data Structures
    cells.append(nbf.v4.new_markdown_cell("### 2. Data Structures Implementation\nIn this section, we implement the core data structures: **Trie**, **Priority Queue (Min-Heap)**, and **Binary Search Tree (BST)**."))
    cells.append(nbf.v4.new_markdown_cell("#### 2.1 Trie (Prefix Tree)"))
    cells.append(nbf.v4.new_code_cell(read_file('data_structures/trie.py')))
    
    cells.append(nbf.v4.new_markdown_cell("#### 2.2 Priority Queue (Min-Heap)"))
    cells.append(nbf.v4.new_code_cell(read_file('data_structures/priority_queue.py')))
    
    cells.append(nbf.v4.new_markdown_cell("#### 2.3 Binary Search Tree (BST)"))
    cells.append(nbf.v4.new_code_cell(read_file('data_structures/bst.py')))
    
    # NLP Pipeline
    cells.append(nbf.v4.new_markdown_cell("### 3. NLP Pipeline\nImplementation of the Text Preprocessor, Medical Tokenizer, and custom TF-IDF Vectorizer."))
    cells.append(nbf.v4.new_markdown_cell("#### 3.1 Text Preprocessor"))
    cells.append(nbf.v4.new_code_cell(read_file('nlp/preprocessor.py')))
    
    cells.append(nbf.v4.new_markdown_cell("#### 3.2 Medical Tokenizer"))
    tokenizer_code = read_file('nlp/tokenizer.py')
    tokenizer_code = tokenizer_code.replace("from data_structures.trie import MedicalTrie", "")
    tokenizer_code = tokenizer_code.replace("from nlp.preprocessor import TextPreprocessor", "")
    tokenizer_code = tokenizer_code.replace("import sys\nimport os\n\n# Add parent directory to path for imports\nsys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))\n", "")
    cells.append(nbf.v4.new_code_cell(tokenizer_code))
    
    cells.append(nbf.v4.new_markdown_cell("#### 3.3 Custom TF-IDF Vectorizer"))
    cells.append(nbf.v4.new_code_cell(read_file('nlp/tfidf_engine.py')))
    
    # Classification
    cells.append(nbf.v4.new_markdown_cell("### 4. Classification & Evaluation\nImplementation of the Ensemble Classifier wrapper, Evaluator, and Explainer (which uses the Priority Queue)."))
    
    cells.append(nbf.v4.new_markdown_cell("#### 4.1 Ensemble Classifier"))
    classifier_code = read_file('classification/classifier.py')
    cells.append(nbf.v4.new_code_cell(classifier_code))
    
    cells.append(nbf.v4.new_markdown_cell("#### 4.2 Model Evaluator"))
    eval_code = read_file('classification/evaluator.py')
    cells.append(nbf.v4.new_code_cell(eval_code))
    
    cells.append(nbf.v4.new_markdown_cell("#### 4.3 Classification Explainer"))
    expl_code = read_file('classification/explainer.py')
    expl_code = expl_code.replace("from data_structures.priority_queue import PriorityQueue", "")
    expl_code = expl_code.replace("import sys\nimport os\n\n# Add parent directory to path for imports\nsys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))\n", "")
    cells.append(nbf.v4.new_code_cell(expl_code))
    
    # Pipeline
    cells.append(nbf.v4.new_markdown_cell("### 5. Pipeline Integration\nDataLoader and the Master Classification Pipeline."))
    
    cells.append(nbf.v4.new_markdown_cell("#### 5.1 DataLoader"))
    cells.append(nbf.v4.new_code_cell(read_file('pipeline/data_loader.py')))
    
    cells.append(nbf.v4.new_markdown_cell("#### 5.2 Classification Pipeline"))
    pipe_code = read_file('pipeline/pipeline.py')
    imports_to_remove = [
        "from nlp.preprocessor import TextPreprocessor",
        "from nlp.tokenizer import MedicalTokenizer",
        "from nlp.tfidf_engine import TFIDFVectorizer",
        "from classification.classifier import EnsembleClassifier",
        "from classification.evaluator import ModelEvaluator",
        "from classification.explainer import ClassificationExplainer",
        "from pipeline.data_loader import DataLoader",
        "import sys\nimport os\nimport time\nfrom collections import deque\n\n# Add parent directory to path for imports\nsys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))\n"
    ]
    for imp in imports_to_remove:
        pipe_code = pipe_code.replace(imp, "")
    cells.append(nbf.v4.new_code_cell(pipe_code))
    
    # Execution
    cells.append(nbf.v4.new_markdown_cell("### 6. Execution and Evaluation\nRunning the full pipeline."))
    execution_code = """# Initialize the pipeline
pipeline = ClassificationPipeline(data_path='dataset/refined_medical_dataset.csv', max_vocab_size=5000, min_freq=2)

# IMPORTANT: You must place the dataset in the 'dataset' folder.
# Download from Kaggle: https://www.kaggle.com/datasets/praveengovi/medical-text-classification

# Uncomment to run training (if dataset is available)
pipeline.train(test_ratio=0.2)
"""
    cells.append(nbf.v4.new_code_cell(execution_code))
    
    cells.append(nbf.v4.new_markdown_cell("### 7. Explainability Demonstration"))
    explain_code = """# Explain a prediction
sample_text = "The patient presented with severe chest pain, elevated heart rate, and hypertension. ECG showed abnormalities."

# Uncomment to run (if pipeline is trained)
print(pipeline.explain(sample_text, top_k=5))
"""
    cells.append(nbf.v4.new_code_cell(explain_code))
    
    nb['cells'] = cells
    
    with open('medical_text_classifier.ipynb', 'w') as f:
        nbf.write(nb, f)
        
    print("Notebook 'medical_text_classifier.ipynb' created successfully!")

if __name__ == '__main__':
    create_notebook()

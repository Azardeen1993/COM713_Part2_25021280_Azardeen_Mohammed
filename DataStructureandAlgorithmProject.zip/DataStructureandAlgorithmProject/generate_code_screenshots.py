import os
from pygments import highlight
from pygments.lexers import PythonLexer
from pygments.formatters import ImageFormatter

# Create output folder for screenshots
os.makedirs('output', exist_ok=True)

# Define snippets to capture
snippets = {
    'code_trie.png': ('data_structures/trie.py', 46, 61),
    'code_pq.png': ('data_structures/priority_queue.py', 16, 29),
    'code_bst.png': ('data_structures/bst.py', 39, 49),
    'code_explainer.png': ('classification/explainer.py', 56, 73)
}

# Image formatting settings
formatter = ImageFormatter(
    font_name='Courier New',
    font_size=20,
    line_numbers=True,
    style='monokai',
    background_color='#1E1E1E',
    line_number_bg='#2D2D2D',
    line_number_fg='#929292',
    line_number_separator=True
)

for filename, (filepath, start_line, end_line) in snippets.items():
    with open(filepath, 'r') as f:
        lines = f.readlines()
        
    code_snippet = "".join(lines[start_line-1:end_line])
    
    with open(f'output/{filename}', 'wb') as f:
        f.write(highlight(code_snippet, PythonLexer(), formatter))

print("Code screenshots generated successfully!")

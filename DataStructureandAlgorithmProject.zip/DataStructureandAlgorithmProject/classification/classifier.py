"""
Classifier Framework for Medical Text Classification
==================================================
Module: COM713 - Advanced Data Structures and Algorithms
Author: [Student Name]
Date: 2026

This module implements the classification framework. While we use sklearn
for the underlying Random Forest / Decision Tree algorithms (as re-implementing
a full Random Forest would detract from the core focus on data structures),
we wrap them in an OOP framework to manage sparse dictionaries and ensemble
voting logic.
"""

from abc import ABC, abstractmethod
import numpy as np

# We use sklearn's Random Forest as the underlying predictive engine
# to provide robust baseline performance, whilst our wrapper handles
# sparse dictionary representations natively.
from sklearn.ensemble import RandomForestClassifier


class BaseClassifier(ABC):
    """
    Abstract base class defining the standard interface for all classifiers
    in the system. Enforces OOP design principles (Polymorphism).
    """

    def __init__(self):
        self.is_trained = False
        self.classes = []

    @abstractmethod
    def train(self, X_sparse, y):
        """Train the model on sparse TF-IDF vectors."""
        pass

    @abstractmethod
    def predict(self, X_sparse):
        """Predict class labels for sparse TF-IDF vectors."""
        pass

    @abstractmethod
    def predict_proba(self, X_sparse):
        """Predict class probabilities for sparse TF-IDF vectors."""
        pass


class EnsembleClassifier(BaseClassifier):
    """
    An ensemble classifier that wraps sklearn's Random Forest but natively
    handles our custom sparse dictionary representation from TFIDFVectorizer.

    The Random Forest is a natural choice as it implicitly builds decision
    trees based on feature thresholds, complementing our TF-IDF features.
    """

    def __init__(self, vocab_size, n_estimators=100, max_depth=None, random_state=42):
        """
        Initialise the Ensemble Classifier.

        Args:
            vocab_size (int): Total vocabulary size (d).
            n_estimators (int): Number of trees in the forest.
            max_depth (int): Max depth of trees.
            random_state (int): Seed for reproducibility.
        """
        super().__init__()
        self.vocab_size = vocab_size
        self.model = RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            random_state=random_state,
            n_jobs=-1  # Use all cores
        )

    def _dict_to_dense(self, sparse_dicts):
        """
        Convert our custom list of sparse dictionaries to a dense numpy array
        for compatibility with sklearn.

        Time Complexity: O(N × d) where N=docs, d=vocab size.
        Space Complexity: O(N × d) memory.
        """
        N = len(sparse_dicts)
        dense_matrix = np.zeros((N, self.vocab_size))

        for i, vector_dict in enumerate(sparse_dicts):
            for idx, val in vector_dict.items():
                dense_matrix[i, idx] = val

        return dense_matrix

    def train(self, X_sparse, y):
        """
        Train the Random Forest classifier.

        Args:
            X_sparse (list[dict]): List of TF-IDF sparse dictionaries.
            y (list): Target labels.

        Time Complexity: O(N × d) for conversion + O(Trees × N × log(N) × d) for training.
        """
        print(f"Converting {len(X_sparse)} sparse vectors to dense matrix...")
        X_dense = self._dict_to_dense(X_sparse)

        print("Training Random Forest ensemble...")
        self.model.fit(X_dense, y)
        self.classes = self.model.classes_
        self.is_trained = True
        print("Training complete.")

    def predict(self, X_sparse):
        """
        Predict class labels.

        Args:
            X_sparse (list[dict]): List of sparse dictionaries.
        """
        if not self.is_trained:
            raise RuntimeError("Classifier must be trained before predicting.")

        X_dense = self._dict_to_dense(X_sparse)
        return self.model.predict(X_dense)

    def predict_proba(self, X_sparse):
        """
        Predict class probabilities.

        Args:
            X_sparse (list[dict] or dict): Sparse dictionaries.
        """
        if not self.is_trained:
            raise RuntimeError("Classifier must be trained before predicting.")

        # Handle single dictionary case
        if isinstance(X_sparse, dict):
            X_sparse = [X_sparse]

        X_dense = self._dict_to_dense(X_sparse)
        return self.model.predict_proba(X_dense)

    def get_feature_importance(self):
        """
        Return the raw feature importances from the Random Forest.

        Returns:
            np.ndarray: Array of importances matching vocabulary size.
        """
        if not self.is_trained:
            return np.zeros(self.vocab_size)
        return self.model.feature_importances_

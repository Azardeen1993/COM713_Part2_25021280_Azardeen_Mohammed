"""
Model Evaluator for Medical Text Classification
===============================================
Module: COM713 - Advanced Data Structures and Algorithms
Author: [Student Name]
Date: 2026

This module implements standard evaluation metrics for classification tasks.
While libraries like sklearn provide these natively, implementing them from
scratch demonstrates algorithmic understanding of how these metrics are calculated.

Calculates:
    - Accuracy
    - Precision (Macro-averaged)
    - Recall (Macro-averaged)
    - F1-Score (Macro-averaged)
    - Confusion Matrix
"""

class ModelEvaluator:
    """
    Evaluator for multi-class classification models.

    Computes standard metrics by first calculating True Positives (TP),
    False Positives (FP), and False Negatives (FN) for each class.
    """

    def __init__(self, classes):
        """
        Initialise evaluator with the list of possible classes.

        Args:
            classes (list): Ordered list of class labels.
        """
        self.classes = classes
        self.class_to_idx = {cls: i for i, cls in enumerate(classes)}
        self.num_classes = len(classes)

    def _get_counts(self, y_true, y_pred):
        """
        Calculate TP, FP, FN for each class.

        Time Complexity: O(N) where N is number of samples.
        """
        # Initialize counts for each class
        tp = [0] * self.num_classes
        fp = [0] * self.num_classes
        fn = [0] * self.num_classes

        for true, pred in zip(y_true, y_pred):
            true_idx = self.class_to_idx.get(true, -1)
            pred_idx = self.class_to_idx.get(pred, -1)

            if true_idx == -1 or pred_idx == -1:
                continue

            if true == pred:
                tp[true_idx] += 1
            else:
                fp[pred_idx] += 1
                fn[true_idx] += 1

        return tp, fp, fn

    def accuracy(self, y_true, y_pred):
        """
        Calculate overall accuracy.
        Time Complexity: O(N)
        """
        correct = sum(1 for true, pred in zip(y_true, y_pred) if true == pred)
        return correct / len(y_true) if len(y_true) > 0 else 0.0

    def precision(self, y_true, y_pred):
        """
        Calculate macro-averaged precision.
        Time Complexity: O(N)
        """
        tp, fp, _ = self._get_counts(y_true, y_pred)
        precisions = []

        for i in range(self.num_classes):
            if tp[i] + fp[i] == 0:
                precisions.append(0.0)
            else:
                precisions.append(tp[i] / (tp[i] + fp[i]))

        return sum(precisions) / self.num_classes

    def recall(self, y_true, y_pred):
        """
        Calculate macro-averaged recall.
        Time Complexity: O(N)
        """
        tp, _, fn = self._get_counts(y_true, y_pred)
        recalls = []

        for i in range(self.num_classes):
            if tp[i] + fn[i] == 0:
                recalls.append(0.0)
            else:
                recalls.append(tp[i] / (tp[i] + fn[i]))

        return sum(recalls) / self.num_classes

    def f1_score(self, y_true, y_pred):
        """
        Calculate macro-averaged F1 score.
        Time Complexity: O(N)
        """
        tp, fp, fn = self._get_counts(y_true, y_pred)
        f1_scores = []

        for i in range(self.num_classes):
            p_den = tp[i] + fp[i]
            r_den = tp[i] + fn[i]

            p = tp[i] / p_den if p_den > 0 else 0.0
            r = tp[i] / r_den if r_den > 0 else 0.0

            if p + r == 0:
                f1_scores.append(0.0)
            else:
                f1_scores.append(2 * (p * r) / (p + r))

        return sum(f1_scores) / self.num_classes

    def confusion_matrix(self, y_true, y_pred):
        """
        Generate a confusion matrix.

        Time Complexity: O(N)
        Space Complexity: O(C^2) where C is number of classes.

        Returns:
            list[list[int]]: 2D array representing the confusion matrix.
        """
        matrix = [[0 for _ in range(self.num_classes)] for _ in range(self.num_classes)]

        for true, pred in zip(y_true, y_pred):
            true_idx = self.class_to_idx.get(true, -1)
            pred_idx = self.class_to_idx.get(pred, -1)

            if true_idx != -1 and pred_idx != -1:
                matrix[true_idx][pred_idx] += 1

        return matrix

    def classification_report(self, y_true, y_pred):
        """
        Generate a formatted text report showing main classification metrics.
        """
        tp, fp, fn = self._get_counts(y_true, y_pred)

        report = f"{'Class':<30} | {'Precision':<10} | {'Recall':<10} | {'F1-Score':<10}\n"
        report += "-" * 68 + "\n"

        for i, cls_name in enumerate(self.classes):
            p_den = tp[i] + fp[i]
            r_den = tp[i] + fn[i]

            p = tp[i] / p_den if p_den > 0 else 0.0
            r = tp[i] / r_den if r_den > 0 else 0.0
            f1 = 2 * (p * r) / (p + r) if (p + r) > 0 else 0.0

            report += f"{cls_name:<30} | {p:.4f}     | {r:.4f}     | {f1:.4f}\n"

        report += "-" * 68 + "\n"
        report += f"{'Macro Avg':<30} | {self.precision(y_true, y_pred):.4f}     | {self.recall(y_true, y_pred):.4f}     | {self.f1_score(y_true, y_pred):.4f}\n"
        report += f"{'Overall Accuracy':<30} | {self.accuracy(y_true, y_pred):.4f}\n"

        return report

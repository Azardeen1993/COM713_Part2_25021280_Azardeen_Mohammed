"""
Classification Explainer for Medical Text Classification
======================================================
Module: COM713 - Advanced Data Structures and Algorithms
Author: [Student Name]
Date: 2026

This module provides the explainability layer for the classifier, addressing
the "black box" limitation identified in recent literature.

It uses the Priority Queue (Min-Heap) data structure to rank the most
influential terms in a specific document that drove the model's prediction.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_structures.priority_queue import PriorityQueue


class ClassificationExplainer:
    """
    Explains model predictions by identifying which terms in the input text
    contributed most to the classification decision.

    This directly addresses the gap identified in the 2025 ETASR paper
    regarding the lack of interpretability in deep learning models.
    """

    def __init__(self, tokenizer, vectorizer, classifier):
        """
        Initialise the explainer.

        Args:
            tokenizer (MedicalTokenizer): The fitted tokenizer.
            vectorizer (TFIDFVectorizer): The fitted vectorizer.
            classifier (EnsembleClassifier): The trained classifier.
        """
        self.tokenizer = tokenizer
        self.vectorizer = vectorizer
        self.classifier = classifier

    def explain_prediction(self, text, top_k=5):
        """
        Explain why a specific text was classified the way it was.

        Algorithm:
            1. Tokenize and vectorise the text (TF-IDF)
            2. Get the global feature importances from the classifier
            3. For each term in the document, calculate its local contribution
               Local Contribution = TF-IDF Score × Global Importance
            4. Use a PriorityQueue (Min-Heap) to efficiently extract the Top K terms
            5. Return the explanation along with the prediction and confidence

        Args:
            text (str): The raw text to explain.
            top_k (int): Number of top contributing terms to return.

        Time Complexity: O(U × log K) where U is unique terms in doc, K is top_k.
        Space Complexity: O(K) for the heap.

        Returns:
            dict: Explanation dictionary containing prediction, confidence,
                  and top contributing terms.
        """
        # 1. Pipeline execution for the single text
        tokens = self.tokenizer.tokenize(text)
        tfidf_vector = self.vectorizer.transform(text)
        
        if not tfidf_vector:
            return {
                "prediction": "Unknown (Empty/No Vocabulary Match)",
                "confidence": 0.0,
                "top_terms": []
            }

        # Predict
        prediction = self.classifier.predict([tfidf_vector])[0]
        probabilities = self.classifier.predict_proba([tfidf_vector])[0]
        
        # Get index of prediction to find confidence
        pred_idx = list(self.classifier.classes).index(prediction)
        confidence = probabilities[pred_idx]

        # 2. Get global feature importance
        global_importance = self.classifier.get_feature_importance()

        # 3 & 4. Calculate local contribution and use Min-Heap for Top K
        # We use PriorityQueue(capacity=top_k) for O(U log K) extraction
        pq = PriorityQueue(capacity=top_k)

        for idx, tfidf_score in tfidf_vector.items():
            # Local contribution = TF-IDF * Global Importance of that feature
            contribution = tfidf_score * global_importance[idx]
            
            # Reconstruct word from index
            word = self.tokenizer.get_index_word(idx)
            
            if contribution > 0:
                # Push to min-heap. If it's larger than the smallest in the top K,
                # the heap handles replacement automatically.
                pq.push(contribution, word)

        # 5. Extract top K from heap
        top_terms = []
        for score, word in pq.get_top_k():
            top_terms.append({
                "term": word,
                "contribution_score": score,
                "category_distribution": self.tokenizer.trie.get_category_distribution(word)
            })

        return {
            "prediction": prediction,
            "confidence": confidence,
            "top_terms": top_terms
        }

    def generate_explanation_report(self, text, top_k=5):
        """
        Generate a human-readable text report of the explanation.
        """
        explanation = self.explain_prediction(text, top_k)
        
        report = "=" * 50 + "\n"
        report += "CLASSIFICATION EXPLANATION REPORT\n"
        report += "=" * 50 + "\n"
        
        report += f"Predicted Category : {explanation['prediction']}\n"
        report += f"Confidence Score   : {explanation['confidence'] * 100:.2f}%\n"
        report += "-" * 50 + "\n"
        
        report += f"Top {top_k} Contributing Medical Terms:\n"
        
        if not explanation['top_terms']:
            report += "No vocabulary terms found in document.\n"
        else:
            for i, term_info in enumerate(explanation['top_terms']):
                term = term_info['term']
                score = term_info['contribution_score']
                dist = term_info['category_distribution']
                
                # Format distribution string
                dist_str = ", ".join([f"{k}:{v}" for k, v in dist.items() if v > 0])
                
                report += f"{i+1}. '{term}' (Impact: {score:.4f})\n"
                report += f"    Corpus frequency in categories: {dist_str}\n"
                
        report += "=" * 50 + "\n"
        return report

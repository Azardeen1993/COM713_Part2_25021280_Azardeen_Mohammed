import re

with open('Gen_AI_Transcript_Clean.md', 'r') as f:
    text = f.read()

# Remove user state lines (The current local time is..., The user's current state is as follows:, etc.)
text = re.sub(r'The current local time is:.*?\n\n', '', text, flags=re.DOTALL)
text = re.sub(r'The user\'s current state is as follows:.*?---\n', '---\n', text, flags=re.DOTALL)
text = re.sub(r'The user changed setting `Model Selection`.*?\n', '', text)
text = re.sub(r'The following is an <EPHEMERAL_MESSAGE>.*?</EPHEMERAL_MESSAGE>', '', text, flags=re.DOTALL)

# Cleanup empty responses
text = re.sub(r'\*\*AI Assistance Provided:\*\*\n---\s*\[Response summarized for brevity\]', '**AI Assistance Provided:**\n[Tool executions and code generation performed]\n', text)
text = re.sub(r'--- \[Response summarized for brevity\]', '[Action executed based on requirements]', text)

# Final cleanup of excessive newlines
text = re.sub(r'\n{3,}', '\n\n', text)

with open('Gen_AI_Transcript_Clean.md', 'w') as f:
    f.write(text.strip())

# data_structures package
# Contains custom implementations of Trie, Priority Queue (Min-Heap), and Binary Search Tree
from .trie import TrieNode, MedicalTrie
from .priority_queue import MinHeapItem, PriorityQueue
from .bst import BSTNode, BinarySearchTree

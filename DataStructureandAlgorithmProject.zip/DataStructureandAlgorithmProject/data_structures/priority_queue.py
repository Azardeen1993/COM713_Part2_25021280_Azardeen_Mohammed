"""
Priority Queue (Min-Heap) Data Structure for Medical Text Classification
========================================================================
Module: COM713 - Advanced Data Structures and Algorithms
Author: [Student Name]
Date: 2026

This module implements a Priority Queue using a binary min-heap, designed
for efficient top-K feature selection and category ranking in the medical
text classification pipeline.

The min-heap enables O(n log k) top-K selection compared to O(n log n)
for a full sort, which is significant when selecting the most relevant
features from a large vocabulary.

Key Features:
    - O(log n) push and pop operations
    - O(1) peek at minimum element
    - O(n log k) top-K selection
    - Custom comparison via MinHeapItem wrapper

References:
    - Cormen, T.H. et al. (2009) Introduction to Algorithms, 3rd edn.
    - Williams, J.W.J. (1964) 'Algorithm 232: Heapsort', CACM.
"""


class MinHeapItem:
    """
    Wrapper class for items stored in the priority queue.

    Encapsulates a score-item pair and provides comparison operators
    for heap ordering. The heap is ordered by score (ascending),
    so the item with the lowest score is at the top.

    For top-K maximum selection, we use a min-heap of size K:
    the heap root holds the smallest score among the current top-K,
    and new items replace it only if they have a higher score.

    Attributes:
        score (float): The priority/relevance score of the item.
        item (any): The actual data being stored (e.g., term name, category).

    Time Complexity:
        - All comparison operations: O(1)
    """

    def __init__(self, score, item):
        """
        Initialise a MinHeapItem with a score and associated data.

        Args:
            score (float): The priority score (lower = higher priority in min-heap).
            item (any): The data payload associated with this score.
        """
        self.score = score
        self.item = item

    def __lt__(self, other):
        """Less-than comparison based on score (for heap ordering)."""
        return self.score < other.score

    def __le__(self, other):
        """Less-than-or-equal comparison based on score."""
        return self.score <= other.score

    def __gt__(self, other):
        """Greater-than comparison based on score."""
        return self.score > other.score

    def __ge__(self, other):
        """Greater-than-or-equal comparison based on score."""
        return self.score >= other.score

    def __eq__(self, other):
        """Equality comparison based on score."""
        if not isinstance(other, MinHeapItem):
            return False
        return self.score == other.score

    def __repr__(self):
        """String representation for debugging."""
        return f"MinHeapItem(score={self.score:.4f}, item={self.item})"


class PriorityQueue:
    """
    A priority queue implementation using a binary min-heap.

    This data structure is used in the medical text classification pipeline for:
        1. Top-K feature selection: Efficiently selecting the K most important
           TF-IDF features from a large vocabulary.
        2. Category ranking: Ranking predicted categories by confidence score
           to determine the most likely medical condition.
        3. Term relevance ranking: In the explainability module, ranking which
           terms contributed most to a classification decision.

    The min-heap maintains the heap property: parent.score <= child.score.
    This enables O(1) access to the minimum element and O(log n) insertion
    and removal.

    For top-K maximum selection, we maintain a min-heap of capacity K.
    New items are only inserted if they score higher than the current minimum,
    ensuring we always have the K highest-scoring items.

    Attributes:
        heap (list): The underlying array storing MinHeapItem objects.
        capacity (int): Maximum number of items to store (for top-K).
                       None means unlimited capacity.

    Example Usage:
        >>> pq = PriorityQueue(capacity=3)
        >>> pq.push(0.9, "Neoplasms")
        >>> pq.push(0.3, "Cardiovascular")
        >>> pq.push(0.7, "Nervous System")
        >>> pq.push(0.8, "Digestive System")  # Replaces "Cardiovascular" (0.3)
        >>> pq.get_top_k(3)
        [(0.9, 'Neoplasms'), (0.8, 'Digestive System'), (0.7, 'Nervous System')]
    """

    def __init__(self, capacity=None):
        """
        Initialise an empty PriorityQueue.

        Args:
            capacity (int, optional): Maximum number of items to store.
                                     If None, the queue has unlimited capacity.

        Time Complexity: O(1)
        Space Complexity: O(1)
        """
        self.heap = []
        self.capacity = capacity

    def push(self, score, item):
        """
        Insert a new item into the priority queue.

        If the queue has a capacity limit (for top-K selection):
            - If not full: insert the item
            - If full and new score > minimum: replace the minimum
            - If full and new score <= minimum: discard the item

        Algorithm (sift-up):
            1. Append item to end of heap array
            2. Compare with parent at index (i-1)//2
            3. If child < parent, swap and continue upward
            4. Stop when heap property is satisfied or root is reached

        Args:
            score (float): The priority score of the item.
            item (any): The data to store.

        Time Complexity: O(log n) where n is the current heap size.
        Space Complexity: O(1) amortised.
        """
        new_item = MinHeapItem(score, item)

        # If capacity is limited (top-K mode)
        if self.capacity is not None and len(self.heap) >= self.capacity:
            # Only insert if new score is greater than current minimum
            if score > self.heap[0].score:
                # Replace the minimum (root) with the new item
                self.heap[0] = new_item
                # Restore heap property by sifting down
                self._sift_down(0)
            # Otherwise, discard the new item (it's not in top-K)
            return

        # Append to the end of the heap
        self.heap.append(new_item)

        # Sift up to maintain the heap property
        self._sift_up(len(self.heap) - 1)

    def pop(self):
        """
        Remove and return the item with the minimum score.

        Algorithm (sift-down):
            1. Save the root element (minimum)
            2. Move the last element to the root position
            3. Remove the last position
            4. Sift down: compare root with children, swap with smaller child
            5. Continue until heap property is restored

        Time Complexity: O(log n) where n is the current heap size.
        Space Complexity: O(1).

        Returns:
            tuple: (score, item) pair of the minimum element.

        Raises:
            IndexError: If the queue is empty.
        """
        if self.is_empty():
            raise IndexError("Priority queue is empty — cannot pop")

        # Save the minimum element (root)
        min_item = self.heap[0]

        # Move the last element to the root
        last_item = self.heap.pop()

        if self.heap:
            self.heap[0] = last_item
            # Sift down to restore heap property
            self._sift_down(0)

        return (min_item.score, min_item.item)

    def peek(self):
        """
        Return the minimum element without removing it.

        Time Complexity: O(1).
        Space Complexity: O(1).

        Returns:
            tuple: (score, item) pair of the minimum element.

        Raises:
            IndexError: If the queue is empty.
        """
        if self.is_empty():
            raise IndexError("Priority queue is empty — cannot peek")

        return (self.heap[0].score, self.heap[0].item)

    def get_top_k(self, k=None):
        """
        Return the top-K items sorted by score in descending order.

        This is the primary method for feature selection and category ranking.
        It extracts all items from a copy of the heap, sorts them, and returns
        the top K.

        Args:
            k (int, optional): Number of top items to return.
                              Defaults to all items if None.

        Time Complexity: O(n log n) for sorting the current items.
        Space Complexity: O(n) for the copy.

        Returns:
            list[tuple]: List of (score, item) pairs sorted descending by score.
        """
        if k is None:
            k = len(self.heap)

        # Sort all items by score in descending order
        sorted_items = sorted(
            [(item.score, item.item) for item in self.heap],
            key=lambda x: x[0],
            reverse=True
        )

        return sorted_items[:k]

    def _sift_up(self, index):
        """
        Restore the heap property by moving an element upward.

        Compares the element at 'index' with its parent and swaps if
        the element is smaller than its parent. Repeats until the
        heap property is satisfied or the root is reached.

        Args:
            index (int): The index of the element to sift up.

        Time Complexity: O(log n) — at most traverses the height of the tree.
        """
        while index > 0:
            parent_index = (index - 1) // 2

            # If current element is smaller than parent, swap
            if self.heap[index] < self.heap[parent_index]:
                self.heap[index], self.heap[parent_index] = (
                    self.heap[parent_index], self.heap[index]
                )
                index = parent_index
            else:
                break  # Heap property satisfied

    def _sift_down(self, index):
        """
        Restore the heap property by moving an element downward.

        Compares the element at 'index' with its children and swaps with
        the smaller child if needed. Repeats until the heap property
        is satisfied or a leaf node is reached.

        Args:
            index (int): The index of the element to sift down.

        Time Complexity: O(log n) — at most traverses the height of the tree.
        """
        size = len(self.heap)

        while True:
            smallest = index
            left_child = 2 * index + 1
            right_child = 2 * index + 2

            # Check if left child exists and is smaller
            if left_child < size and self.heap[left_child] < self.heap[smallest]:
                smallest = left_child

            # Check if right child exists and is smaller
            if right_child < size and self.heap[right_child] < self.heap[smallest]:
                smallest = right_child

            # If a child is smaller, swap and continue
            if smallest != index:
                self.heap[index], self.heap[smallest] = (
                    self.heap[smallest], self.heap[index]
                )
                index = smallest
            else:
                break  # Heap property satisfied

    def is_empty(self):
        """
        Check if the priority queue is empty.

        Time Complexity: O(1).

        Returns:
            bool: True if empty, False otherwise.
        """
        return len(self.heap) == 0

    def size(self):
        """
        Return the current number of items in the queue.

        Time Complexity: O(1).

        Returns:
            int: Number of items currently stored.
        """
        return len(self.heap)

    def clear(self):
        """
        Remove all items from the priority queue.

        Time Complexity: O(1).
        """
        self.heap = []

    def __len__(self):
        """Return the number of items in the queue."""
        return len(self.heap)

    def __repr__(self):
        """String representation of the PriorityQueue."""
        return f"PriorityQueue(size={len(self.heap)}, capacity={self.capacity})"

    def __bool__(self):
        """Return True if the queue is non-empty."""
        return not self.is_empty()

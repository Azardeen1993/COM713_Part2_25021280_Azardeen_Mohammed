"""
Trie (Prefix Tree) Data Structure for Medical Text Classification
=================================================================
Module: COM713 - Advanced Data Structures and Algorithms
Author: [Student Name]
Date: 2026

This module implements a Trie data structure specifically designed for
efficient medical terminology lookup, prefix-based searching, and
category-frequency tracking. The Trie enables O(m) search time where
m is the length of the search term, compared to O(n) for linear search
through a vocabulary list.

Key Features:
    - O(m) insertion and exact-match search
    - Prefix-based search for autocomplete functionality
    - Category frequency tracking per word (which medical categories use this term)
    - Word counting and vocabulary size tracking

References:
    - Cormen, T.H. et al. (2009) Introduction to Algorithms, 3rd edn.
    - Knuth, D.E. (1997) The Art of Computer Programming, Vol. 3.
"""


class TrieNode:
    """
    Represents a single node in the Trie data structure.

    Each node stores:
        - children: A dictionary mapping characters to child TrieNode objects.
                    Using a dictionary provides O(1) average-case child lookup.
        - is_end_of_word: Boolean flag indicating if this node marks the
                         end of a complete word in the Trie.
        - word_count: Number of times this complete word has been inserted.
                     Useful for term frequency tracking.
        - category_freq: Dictionary tracking how many times this word appears
                        in each medical category (e.g., {'Neoplasms': 15, 'Cardiovascular': 8}).

    Time Complexity:
        - __init__: O(1)

    Space Complexity:
        - O(1) per node (excluding children references)
    """

    def __init__(self):
        """Initialise a new TrieNode with empty children and default counters."""
        # Dictionary of character -> TrieNode mappings for child nodes
        # Using dict instead of fixed-size array for memory efficiency
        # with variable character sets (medical text includes letters, digits, hyphens)
        self.children = {}

        # Flag to mark if this node represents the end of a complete word
        self.is_end_of_word = False

        # Counter for how many times this word has been inserted
        # Useful for calculating term frequency (TF) in TF-IDF
        self.word_count = 0

        # Dictionary mapping category names to frequency counts
        # Tracks which medical categories this word appears in and how often
        self.category_freq = {}


class MedicalTrie:
    """
    A Trie (prefix tree) data structure optimised for medical text classification.

    The MedicalTrie provides efficient storage and retrieval of medical terminology,
    supporting operations essential for the text classification pipeline:
        1. Fast exact-match word lookup for vocabulary checking
        2. Prefix-based searching for medical term autocomplete
        3. Category frequency tracking to understand term-category associations
        4. Vocabulary enumeration for feature extraction

    This data structure addresses a key gap identified in the reference article:
    traditional NLP pipelines use linear search (O(n)) for vocabulary lookup,
    whereas the Trie provides O(m) lookup where m is the word length, regardless
    of vocabulary size.

    Attributes:
        root (TrieNode): The root node of the Trie (represents empty prefix).
        size (int): Total number of unique words stored in the Trie.
        total_insertions (int): Total number of insert operations performed.

    Example Usage:
        >>> trie = MedicalTrie()
        >>> trie.insert("carcinoma", "Neoplasms")
        >>> trie.insert("cardiac", "Cardiovascular")
        >>> trie.search("carcinoma")
        True
        >>> trie.starts_with("car")
        ['carcinoma', 'cardiac']
    """

    def __init__(self):
        """Initialise an empty MedicalTrie with a root node."""
        # Root node represents the empty prefix ""
        self.root = TrieNode()

        # Counter for unique words in the Trie
        self.size = 0

        # Counter for total insertions (including duplicates)
        self.total_insertions = 0

    def insert(self, word, category=None):
        """
        Insert a word into the Trie with optional category tracking.

        This method traverses the Trie character by character, creating new
        nodes as needed, and marks the final node as the end of a word.
        If a category is provided, it updates the category frequency counter
        for this word.

        Algorithm:
            1. Start at root node
            2. For each character in the word:
               a. If character not in current node's children, create new TrieNode
               b. Move to the child node for this character
            3. Mark the final node as end_of_word
            4. Increment word_count
            5. Update category frequency if category provided

        Args:
            word (str): The word to insert (will be converted to lowercase).
            category (str, optional): The medical category this word belongs to.
                                     Used for category-frequency tracking.

        Time Complexity: O(m) where m is the length of the word.
        Space Complexity: O(m) in worst case (all new nodes created).

        Returns:
            None
        """
        # Validate input
        if not word or not isinstance(word, str):
            return

        # Convert to lowercase for case-insensitive matching
        word = word.lower().strip()

        if not word:
            return

        # Start traversal from the root node
        current_node = self.root

        # Traverse character by character, creating nodes as needed
        for char in word:
            # If this character doesn't have a child node, create one
            if char not in current_node.children:
                current_node.children[char] = TrieNode()

            # Move to the child node for this character
            current_node = current_node.children[char]

        # Mark the end of the word
        # Only increment size counter if this is a new word
        if not current_node.is_end_of_word:
            current_node.is_end_of_word = True
            self.size += 1

        # Increment word count (tracks duplicates for term frequency)
        current_node.word_count += 1
        self.total_insertions += 1

        # Update category frequency if a category is provided
        if category:
            if category not in current_node.category_freq:
                current_node.category_freq[category] = 0
            current_node.category_freq[category] += 1

    def search(self, word):
        """
        Search for an exact word match in the Trie.

        Traverses the Trie character by character. Returns True only if
        the complete word exists and its final node is marked as end_of_word.

        Args:
            word (str): The word to search for (case-insensitive).

        Time Complexity: O(m) where m is the length of the word.
        Space Complexity: O(1) — no additional space used.

        Returns:
            bool: True if the word exists in the Trie, False otherwise.
        """
        node = self._find_node(word)
        return node is not None and node.is_end_of_word

    def _find_node(self, prefix):
        """
        Internal helper: traverse the Trie to find the node for a given prefix.

        Args:
            prefix (str): The prefix string to traverse.

        Time Complexity: O(m) where m is the length of the prefix.
        Space Complexity: O(1).

        Returns:
            TrieNode or None: The node at the end of the prefix path,
                             or None if the prefix doesn't exist.
        """
        if not prefix or not isinstance(prefix, str):
            return None

        prefix = prefix.lower().strip()
        current_node = self.root

        for char in prefix:
            if char not in current_node.children:
                return None  # Prefix doesn't exist in Trie
            current_node = current_node.children[char]

        return current_node

    def starts_with(self, prefix):
        """
        Find all words in the Trie that start with the given prefix.

        This is particularly useful for medical term autocomplete — given
        a prefix like "cardio", it returns all matching terms such as
        "cardiovascular", "cardiomyopathy", "cardiology", etc.

        Algorithm:
            1. Navigate to the node representing the prefix
            2. Perform DFS from that node to collect all complete words

        Args:
            prefix (str): The prefix to search for (case-insensitive).

        Time Complexity: O(m + k) where m is prefix length and k is the
                        number of matching words (DFS traversal).
        Space Complexity: O(k) for storing results + O(h) for recursion stack
                         where h is the maximum word length.

        Returns:
            list[str]: A list of all words starting with the given prefix.
        """
        results = []
        node = self._find_node(prefix)

        if node is None:
            return results

        # DFS to collect all words from this node
        prefix = prefix.lower().strip()
        self._dfs_collect_words(node, prefix, results)

        return results

    def _dfs_collect_words(self, node, current_prefix, results):
        """
        Internal helper: Depth-first search to collect all complete words
        from a given node.

        Args:
            node (TrieNode): Current node in the DFS traversal.
            current_prefix (str): The prefix built up so far.
            results (list): Accumulator list for found words.

        Time Complexity: O(k) where k is the number of nodes visited.
        Space Complexity: O(h) recursion stack depth.
        """
        # If this node marks the end of a word, add it to results
        if node.is_end_of_word:
            results.append(current_prefix)

        # Recursively explore all children (sorted for deterministic output)
        for char in sorted(node.children.keys()):
            self._dfs_collect_words(
                node.children[char],
                current_prefix + char,
                results
            )

    def get_category_distribution(self, word):
        """
        Get the category frequency distribution for a specific word.

        Returns how many times the word appears in each medical category,
        which is valuable for understanding term-category associations
        and for building category-specific feature weights.

        Args:
            word (str): The word to query (case-insensitive).

        Time Complexity: O(m) where m is the word length.
        Space Complexity: O(c) where c is the number of categories.

        Returns:
            dict: A dictionary mapping category names to frequency counts.
                  Returns empty dict if word not found.

        Example:
            >>> trie.get_category_distribution("tumor")
            {'Neoplasms': 42, 'General Pathological': 5}
        """
        node = self._find_node(word)
        if node is not None and node.is_end_of_word:
            return dict(node.category_freq)  # Return a copy
        return {}

    def get_word_count(self, word):
        """
        Get the total insertion count for a specific word.

        Useful for term frequency (TF) calculation in TF-IDF.

        Args:
            word (str): The word to query.

        Time Complexity: O(m) where m is the word length.

        Returns:
            int: Number of times the word was inserted, or 0 if not found.
        """
        node = self._find_node(word)
        if node is not None and node.is_end_of_word:
            return node.word_count
        return 0

    def get_all_words(self):
        """
        Retrieve all words stored in the Trie.

        Performs a complete DFS traversal from the root to enumerate
        the entire vocabulary. Useful for building feature vectors.

        Time Complexity: O(N) where N is the total number of nodes.
        Space Complexity: O(W × L) where W is the number of words
                         and L is the average word length.

        Returns:
            list[str]: A sorted list of all words in the Trie.
        """
        results = []
        self._dfs_collect_words(self.root, "", results)
        return results

    def delete(self, word):
        """
        Delete a word from the Trie.

        Marks the word's end node as not-end-of-word and prunes
        unnecessary nodes (nodes that have no other children and
        are not end-of-word for another word).

        Args:
            word (str): The word to delete.

        Time Complexity: O(m) where m is the word length.
        Space Complexity: O(m) for the recursion stack.

        Returns:
            bool: True if the word was found and deleted, False otherwise.
        """
        if not word:
            return False

        word = word.lower().strip()
        return self._delete_recursive(self.root, word, 0)

    def _delete_recursive(self, node, word, depth):
        """
        Internal helper: recursively delete a word and prune empty branches.

        Args:
            node (TrieNode): Current node.
            word (str): The word being deleted.
            depth (int): Current depth in the word (character index).

        Returns:
            bool: True if the current node should be deleted by its parent.
        """
        # Base case: reached the end of the word
        if depth == len(word):
            if not node.is_end_of_word:
                return False  # Word doesn't exist
            node.is_end_of_word = False
            node.word_count = 0
            node.category_freq = {}
            self.size -= 1
            # Return True if node has no children (safe to delete)
            return len(node.children) == 0

        char = word[depth]
        if char not in node.children:
            return False  # Word doesn't exist

        # Recurse to the next character
        should_delete_child = self._delete_recursive(
            node.children[char], word, depth + 1
        )

        # If child should be deleted, remove it
        if should_delete_child:
            del node.children[char]
            # Return True if this node is also deletable
            return not node.is_end_of_word and len(node.children) == 0

        return False

    def __len__(self):
        """Return the number of unique words in the Trie."""
        return self.size

    def __contains__(self, word):
        """Support 'in' operator: 'word in trie'."""
        return self.search(word)

    def __repr__(self):
        """String representation of the Trie."""
        return f"MedicalTrie(size={self.size}, total_insertions={self.total_insertions})"

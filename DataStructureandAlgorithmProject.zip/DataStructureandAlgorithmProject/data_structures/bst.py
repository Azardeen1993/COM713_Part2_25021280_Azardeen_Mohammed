"""
Binary Search Tree (BST) Data Structure for Medical Text Classification
=======================================================================
Module: COM713 - Advanced Data Structures and Algorithms
Author: [Student Name]
Date: 2026

This module implements a Binary Search Tree for efficient sorted storage
and range-based queries on TF-IDF scores and feature importance values.

The BST enables:
    - O(log n) average-case insertion and search
    - Efficient range queries: retrieve all terms with TF-IDF scores
      between a given low and high threshold
    - In-order traversal for sorted output

While a hash map provides O(1) lookup, it does not support range queries
or sorted traversal — both essential for feature selection in the
classification pipeline.

References:
    - Cormen, T.H. et al. (2009) Introduction to Algorithms, 3rd edn.
"""


class BSTNode:
    """
    Represents a single node in the Binary Search Tree.

    Each node stores a key-value pair where:
        - key (str): The term/feature name (used for BST ordering)
        - value (float): The associated score (e.g., TF-IDF score)

    Attributes:
        key (str): The lookup key (alphabetically ordered in the BST).
        value (float): The associated numerical value.
        left (BSTNode): Left child (keys < this node's key).
        right (BSTNode): Right child (keys > this node's key).
        count (int): Number of times this key has been inserted (handles duplicates).
    """

    def __init__(self, key, value):
        """
        Initialise a new BST node with a key-value pair.

        Args:
            key (str): The node's key for ordering.
            value (float): The associated value/score.
        """
        self.key = key
        self.value = value
        self.left = None   # Left subtree (keys less than this key)
        self.right = None  # Right subtree (keys greater than this key)
        self.count = 1     # For handling duplicate insertions


class BinarySearchTree:
    """
    A Binary Search Tree for sorted storage of term-score pairs.

    Used in the medical text classification pipeline for:
        1. Sorted storage of TF-IDF scores by term name
        2. Range queries: find all terms with scores in a given range
        3. Ordered traversal for generating sorted feature lists
        4. Efficient term-score lookup

    The BST maintains the invariant: for any node N,
        all keys in N.left < N.key < all keys in N.right

    Attributes:
        root (BSTNode): The root node of the tree.
        size (int): Number of unique keys stored.

    Note: This is an unbalanced BST. Average case is O(log n) but worst
    case (sorted input) degrades to O(n). For production use, an AVL tree
    or Red-Black tree would be preferred, but the standard BST is implemented
    here to clearly demonstrate the data structure and its properties.

    Example Usage:
        >>> bst = BinarySearchTree()
        >>> bst.insert("tumor", 0.85)
        >>> bst.insert("cardiac", 0.72)
        >>> bst.insert("neural", 0.91)
        >>> bst.search("tumor")
        0.85
        >>> bst.range_query("c", "o")  # All terms from "c" to "o"
        [('cardiac', 0.72), ('neural', 0.91)]
    """

    def __init__(self):
        """
        Initialise an empty Binary Search Tree.

        Time Complexity: O(1)
        Space Complexity: O(1)
        """
        self.root = None
        self.size = 0

    def insert(self, key, value):
        """
        Insert a key-value pair into the BST.

        If the key already exists, its value is updated.

        Algorithm:
            1. If tree is empty, create root node
            2. Otherwise, traverse from root:
               a. If key < current.key, go left
               b. If key > current.key, go right
               c. If key == current.key, update value

        Args:
            key (str): The key for ordering (e.g., term name).
            value (float): The associated value (e.g., TF-IDF score).

        Time Complexity: O(log n) average, O(n) worst case (skewed tree).
        Space Complexity: O(log n) average for recursion stack.
        """
        self.root = self._insert_recursive(self.root, key, value)

    def _insert_recursive(self, node, key, value):
        """
        Internal recursive helper for insertion.

        Args:
            node (BSTNode): Current node in the traversal.
            key (str): Key to insert.
            value (float): Value to associate with the key.

        Returns:
            BSTNode: The (potentially new) node at this position.
        """
        # Base case: found an empty spot, create a new node
        if node is None:
            self.size += 1
            return BSTNode(key, value)

        # Recurse based on key comparison
        if key < node.key:
            node.left = self._insert_recursive(node.left, key, value)
        elif key > node.key:
            node.right = self._insert_recursive(node.right, key, value)
        else:
            # Key already exists — update its value and increment count
            node.value = value
            node.count += 1

        return node

    def search(self, key):
        """
        Search for a key and return its associated value.

        Args:
            key (str): The key to search for.

        Time Complexity: O(log n) average, O(n) worst case.
        Space Complexity: O(1) (iterative implementation).

        Returns:
            float or None: The value associated with the key,
                          or None if the key is not found.
        """
        current = self.root

        while current is not None:
            if key < current.key:
                current = current.left
            elif key > current.key:
                current = current.right
            else:
                return current.value  # Found the key

        return None  # Key not found

    def in_order_traversal(self):
        """
        Perform an in-order traversal of the BST.

        Returns all key-value pairs sorted by key in ascending order.
        This is useful for generating sorted feature lists.

        Algorithm:
            1. Recursively traverse left subtree
            2. Visit current node
            3. Recursively traverse right subtree

        Time Complexity: O(n) — visits every node exactly once.
        Space Complexity: O(n) for the result list + O(h) for recursion stack
                         where h is the tree height.

        Returns:
            list[tuple]: List of (key, value) pairs in sorted order.
        """
        results = []
        self._in_order_recursive(self.root, results)
        return results

    def _in_order_recursive(self, node, results):
        """
        Internal recursive helper for in-order traversal.

        Args:
            node (BSTNode): Current node.
            results (list): Accumulator for visited key-value pairs.
        """
        if node is not None:
            # Visit left subtree first (smaller keys)
            self._in_order_recursive(node.left, results)

            # Visit current node
            results.append((node.key, node.value))

            # Visit right subtree (larger keys)
            self._in_order_recursive(node.right, results)

    def range_query(self, low_key, high_key):
        """
        Find all key-value pairs where low_key <= key <= high_key.

        This operation is uniquely suited to the BST — hash maps cannot
        efficiently support range queries. In the classification pipeline,
        this is used to find all terms within a score range or alphabetical
        range.

        Algorithm:
            1. If current key < low_key, skip left subtree (all keys too small)
            2. If current key > high_key, skip right subtree (all keys too large)
            3. If low_key <= current key <= high_key, include current node

        Args:
            low_key (str): Lower bound of the range (inclusive).
            high_key (str): Upper bound of the range (inclusive).

        Time Complexity: O(log n + k) where k is the number of results.
        Space Complexity: O(k) for results + O(h) for recursion stack.

        Returns:
            list[tuple]: List of (key, value) pairs within the range,
                        sorted by key.
        """
        results = []
        self._range_query_recursive(self.root, low_key, high_key, results)
        return results

    def _range_query_recursive(self, node, low_key, high_key, results):
        """
        Internal recursive helper for range queries.

        Efficiently prunes branches that cannot contain keys in the range.

        Args:
            node (BSTNode): Current node.
            low_key (str): Lower bound.
            high_key (str): Upper bound.
            results (list): Accumulator for matching key-value pairs.
        """
        if node is None:
            return

        # Only explore left subtree if there might be keys >= low_key
        if node.key > low_key:
            self._range_query_recursive(node.left, low_key, high_key, results)

        # Include current node if within range
        if low_key <= node.key <= high_key:
            results.append((node.key, node.value))

        # Only explore right subtree if there might be keys <= high_key
        if node.key < high_key:
            self._range_query_recursive(node.right, low_key, high_key, results)

    def find_min(self):
        """
        Find the minimum key in the BST.

        Time Complexity: O(h) where h is the tree height.

        Returns:
            tuple or None: (key, value) of the minimum key, or None if empty.
        """
        if self.root is None:
            return None

        current = self.root
        while current.left is not None:
            current = current.left

        return (current.key, current.value)

    def find_max(self):
        """
        Find the maximum key in the BST.

        Time Complexity: O(h) where h is the tree height.

        Returns:
            tuple or None: (key, value) of the maximum key, or None if empty.
        """
        if self.root is None:
            return None

        current = self.root
        while current.right is not None:
            current = current.right

        return (current.key, current.value)

    def delete(self, key):
        """
        Delete a key from the BST.

        Handles three cases:
            1. Node has no children: simply remove it
            2. Node has one child: replace with child
            3. Node has two children: replace with in-order successor

        Args:
            key (str): The key to delete.

        Time Complexity: O(log n) average, O(n) worst case.
        Space Complexity: O(h) for recursion stack.

        Returns:
            bool: True if the key was found and deleted, False otherwise.
        """
        if self.search(key) is None:
            return False

        self.root = self._delete_recursive(self.root, key)
        self.size -= 1
        return True

    def _delete_recursive(self, node, key):
        """
        Internal recursive helper for deletion.

        Args:
            node (BSTNode): Current node.
            key (str): Key to delete.

        Returns:
            BSTNode: The (potentially modified) node at this position.
        """
        if node is None:
            return None

        if key < node.key:
            node.left = self._delete_recursive(node.left, key)
        elif key > node.key:
            node.right = self._delete_recursive(node.right, key)
        else:
            # Found the node to delete

            # Case 1: No children
            if node.left is None and node.right is None:
                return None

            # Case 2: One child
            if node.left is None:
                return node.right
            if node.right is None:
                return node.left

            # Case 3: Two children
            # Find the in-order successor (smallest key in right subtree)
            successor = node.right
            while successor.left is not None:
                successor = successor.left

            # Replace current node's data with successor's data
            node.key = successor.key
            node.value = successor.value
            node.count = successor.count

            # Delete the successor from the right subtree
            node.right = self._delete_recursive(node.right, successor.key)

        return node

    def get_height(self):
        """
        Calculate the height of the BST.

        Useful for complexity analysis — the height determines the
        worst-case performance of search, insert, and delete operations.

        Time Complexity: O(n).
        Space Complexity: O(h) for recursion stack.

        Returns:
            int: The height of the tree (-1 for empty tree).
        """
        return self._height_recursive(self.root)

    def _height_recursive(self, node):
        """Internal recursive helper for height calculation."""
        if node is None:
            return -1
        left_height = self._height_recursive(node.left)
        right_height = self._height_recursive(node.right)
        return 1 + max(left_height, right_height)

    def __len__(self):
        """Return the number of unique keys in the BST."""
        return self.size

    def __contains__(self, key):
        """Support 'in' operator: 'key in bst'."""
        return self.search(key) is not None

    def __repr__(self):
        """String representation of the BST."""
        return f"BinarySearchTree(size={self.size}, height={self.get_height()})"

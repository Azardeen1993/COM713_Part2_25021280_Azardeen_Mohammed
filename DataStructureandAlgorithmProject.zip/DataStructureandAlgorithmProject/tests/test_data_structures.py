"""
Unit tests for data structures (Trie, Priority Queue, BST)
==========================================================
Module: COM713 - Advanced Data Structures and Algorithms
"""

import sys
import os
import unittest

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_structures.trie import MedicalTrie
from data_structures.priority_queue import PriorityQueue
from data_structures.bst import BinarySearchTree

class TestMedicalTrie(unittest.TestCase):
    def setUp(self):
        self.trie = MedicalTrie()
        self.trie.insert("carcinoma", "Neoplasms")
        self.trie.insert("cardiac", "Cardiovascular")
        self.trie.insert("cardiology", "Cardiovascular")
        
    def test_insert_search(self):
        # Positive cases
        self.assertTrue(self.trie.search("carcinoma"))
        self.assertTrue(self.trie.search("CARDIAC")) # Case insensitive
        
        # Negative cases
        self.assertFalse(self.trie.search("cardio")) # Prefix, but not a full word
        self.assertFalse(self.trie.search("unknown"))
        
    def test_prefix_search(self):
        words = self.trie.starts_with("card")
        self.assertEqual(len(words), 2)
        self.assertIn("cardiac", words)
        self.assertIn("cardiology", words)
        
    def test_category_freq(self):
        self.trie.insert("tumor", "Neoplasms")
        self.trie.insert("tumor", "Neoplasms")
        self.trie.insert("tumor", "Digestive System")
        
        freq = self.trie.get_category_distribution("tumor")
        self.assertEqual(freq["Neoplasms"], 2)
        self.assertEqual(freq["Digestive System"], 1)

    def test_delete(self):
        self.assertTrue(self.trie.search("carcinoma"))
        self.trie.delete("carcinoma")
        self.assertFalse(self.trie.search("carcinoma"))
        self.assertEqual(self.trie.size, 2)


class TestPriorityQueue(unittest.TestCase):
    def test_heap_push_pop(self):
        pq = PriorityQueue()
        pq.push(0.9, "high")
        pq.push(0.1, "low")
        pq.push(0.5, "med")
        
        # Should pop lowest score first (Min-Heap)
        score, item = pq.pop()
        self.assertEqual(score, 0.1)
        self.assertEqual(item, "low")
        
    def test_top_k(self):
        pq = PriorityQueue(capacity=3)
        pq.push(0.1, "A")
        pq.push(0.9, "B")
        pq.push(0.5, "C")
        pq.push(0.8, "D") # Should push out A (0.1)
        
        top_k = pq.get_top_k(3)
        self.assertEqual(len(top_k), 3)
        # Should be sorted descending by default
        self.assertEqual(top_k[0][0], 0.9)
        self.assertEqual(top_k[0][1], "B")
        self.assertEqual(top_k[-1][0], 0.5)


class TestBinarySearchTree(unittest.TestCase):
    def setUp(self):
        self.bst = BinarySearchTree()
        self.bst.insert("m", 50)
        self.bst.insert("a", 10)
        self.bst.insert("z", 90)
        self.bst.insert("f", 30)

    def test_search(self):
        self.assertEqual(self.bst.search("a"), 10)
        self.assertEqual(self.bst.search("z"), 90)
        self.assertIsNone(self.bst.search("unknown"))

    def test_range_query(self):
        # Alphabetical range
        results = self.bst.range_query("e", "n")
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0][0], "f")
        self.assertEqual(results[1][0], "m")

    def test_delete(self):
        self.bst.delete("a") # Leaf node
        self.assertIsNone(self.bst.search("a"))
        self.assertEqual(self.bst.size, 3)

if __name__ == '__main__':
    unittest.main()
